package com.myoor.PlaceOrderPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PlaceOrderPage {
	WebDriver driver;

	@FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div[1]/div[2]/div/div[1]/div[1]/a")
	WebElement clickAddCartElement;

	@FindBy(xpath = "//*[@id=\"do_action\"]/div[1]/div/div/a")
	WebElement checkOutElement;

	@FindBy(xpath = "//*[@id=\"checkoutModal\"]/div/div/div[2]/p[2]/a/u")
	WebElement registerElement;

	@FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")
	WebElement clickCartElement;
	//*[@id="header"]/div/div/div/div[2]/div/ul/li[3]/a
	@FindBy(xpath = "//*[@id=\"address_delivery\"]/li[4]")
	WebElement deliveryAddressElement;
	
	@FindBy(xpath = "//*[@id=\"address_invoice\"]/li[4]")
	WebElement billingAddressElement;
	

	@FindBy(xpath = "//*[@id=\"ordermsg\"]/textarea")
	WebElement descriptionElement;

	@FindBy(xpath = "//*[@id=\"cart_items\"]/div/div[7]/a")
	WebElement clickPlaceOrderElement;

	@FindBy(xpath = "//*[@id=\"payment-form\"]/div[1]/div/input")
	WebElement nameOnCardElement;

	@FindBy(xpath = "//*[@id=\"payment-form\"]/div[2]/div/input")
	WebElement cardNumberElement;

	@FindBy(xpath = "//*[@id=\"payment-form\"]/div[3]/div[1]/input")
	WebElement cvvElement;

	@FindBy(xpath = "//*[@id=\"payment-form\"]/div[3]/div[2]/input")
	WebElement expiryMonthElement;

	@FindBy(xpath = "//*[@id=\"payment-form\"]/div[3]/div[3]/input")
	WebElement expiryYearElement;

	@FindBy(xpath = "//*[@id=\"submit\"]")
	WebElement payAndConfirmElement;
	
	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div/p")
	WebElement successtextElement;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div/p")
	WebElement clickDownloadInvoiceElement;
	
	
	public PlaceOrderPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void clickaddCart() {
		clickAddCartElement.click();
	}

	public void checkOut() {
		checkOutElement.click();
	}

	public void clickRegister() {
		registerElement.click();

	}

	public void clickCart() {
		clickCartElement.click();

	}

	public String getDeliveryAddress() {
		String gettAddressHeader = deliveryAddressElement.getText();
		return gettAddressHeader;

	}
	public String getBillingAddress() {
		String gettAddressHeader = billingAddressElement.getText();
		return gettAddressHeader;

	}

	public void sendDescription(String sendDescription) {
		descriptionElement.sendKeys(sendDescription);
		clickPlaceOrderElement.click();
	}

	public void paymentDetails(String nameOnCard, String cardNumber, String cvvNumber, String expiryMonth,
			String expiryYear) {
		nameOnCardElement.sendKeys(nameOnCard);
		cardNumberElement.sendKeys(cardNumber);
		cvvElement.sendKeys(cvvNumber);
		expiryMonthElement.sendKeys(expiryMonth);
		expiryYearElement.sendKeys(expiryYear);
		payAndConfirmElement.click();
	}
	public String getSuccessText() {
		String successText = successtextElement.getText();
		return successText;
	}
	public void clickDownloadInvoice() {
		clickDownloadInvoiceElement.click();
	}
	

}
