package com.myorrg.SearchProductPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProductSearchPage {
	WebDriver driver;

	@FindBy(xpath = "//*[@id=\"search_product\"]")
	WebElement searchProductElement;

	@FindBy(xpath = "//*[@id=\"submit_search\"]")
	WebElement clickElement;

	@FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div/h2")
	WebElement searchedElement;

	@FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div/div[2]/div/div[1]/div[1]/a")
	WebElement clickAddToCartElement;
	
	@FindBy(xpath = "//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a/u")
	WebElement clickViewCartElement;
	
	
	@FindBy(xpath = "//*[@id=\"product-2\"]/td[2]/h4/a")
	WebElement productInCartElement;
	
	public ProductSearchPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void clickSearch() {
		searchProductElement.sendKeys("Tshirt");
		clickElement.click();
	}

	public String searcheTestdPage() {
		String searchedText = searchedElement.getText();
		return searchedText;
	}
	
	public void clickAddCart() {
		clickAddToCartElement.click();
		clickViewCartElement.click();
	}
	public String getProductInCartText() {
		String productCartText = productInCartElement.getText();
		return productCartText;
	}
}
