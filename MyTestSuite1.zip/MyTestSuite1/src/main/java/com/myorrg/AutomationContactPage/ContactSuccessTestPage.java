package com.myorrg.AutomationContactPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ContactSuccessTestPage {
	WebDriver driver;
	
	@FindBy(xpath = "//*[@id=\"contact-page\"]/div[2]/div[1]/div/div[2]")
	WebElement contactSuccessTextElement;

	@FindBy(xpath = "//*[@id=\"form-section\"]/a/span")
	WebElement clickHomeTextElement;
	
	
	public ContactSuccessTestPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public String getSuccessHeaderText() {
		String headerText = contactSuccessTextElement.getText();
		return headerText;
	}
	

	public void clickHome() {
		clickHomeTextElement.click();
	}
}
