package com.myorrg.AutomationContactPage;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ContactTestPage {
	WebDriver driver;
	@FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[8]/a")
	WebElement clickContactUsElement;

	@FindBy(xpath = "//*[@id=\"contact-page\"]/div[2]/div[1]/div/h2")
	WebElement contactTextElement;

	@FindBy(xpath = "//*[@id=\"contact-us-form\"]/div[1]/input")
	WebElement nameTextElement;

	@FindBy(xpath = "//*[@id=\"contact-us-form\"]/div[2]/input")
	WebElement emailTextElement;

	@FindBy(xpath = "//*[@id=\"contact-us-form\"]/div[3]/input")
	WebElement subjectTextElement;

	@FindBy(xpath = "//*[@id=\"message\"]")
	WebElement messageTextElement;

	@FindBy(xpath = "//*[@id=\"contact-us-form\"]/div[5]/input")
	WebElement fileUploadTextElement;

	@FindBy(xpath = "//*[@id=\"contact-us-form\"]/div[6]/input")
	WebElement submitTextElement;

	public ContactTestPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void clickContactUs() {
		clickContactUsElement.click();

	}

	public String getContactHeaderText() {
		String headerText = contactTextElement.getText();
		return headerText;

	}

	public void fillDetails(String name, String email, String subject, String message) {
		nameTextElement.sendKeys(name);
		emailTextElement.sendKeys(email);
		subjectTextElement.sendKeys(subject);
		messageTextElement.sendKeys(message);
		submitTextElement.click();
	}

	public void fileUpload() {
		fileUploadTextElement.sendKeys("C:\\Users\\shaik\\OneDrive\\Desktop");
		submitTextElement.click();

	}
	public String alertText() {
		String al = driver.switchTo().alert().getText();
		return al;
	}

	public void alert() {
		Alert al = driver.switchTo().alert();
		al.accept();
	}
}
