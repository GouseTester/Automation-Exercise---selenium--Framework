package com.myorrg.AddProduct;

import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddProductPage extends FeedTest {
	WebDriver driver;
	@FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div/div[2]/div/div[1]/div[1]/a")
	WebElement clickAddCartElement;

	@FindBy(xpath = "//*[@id=\"cartModal\"]/div/div/div[3]/button")
	WebElement clickContinueElement;

	@FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div/div[3]/div/div[1]/div[1]/a")
	WebElement clickAddCartElement1;

	@FindBy(xpath = "//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a/u")
	WebElement clickViewCartElement;

	@FindBy(xpath = "//*[@id=\"product-1\"]/td[3]/p")
	WebElement priceElement;

	@FindBy(xpath = "//*[@id=\"product-2\"]/td[3]/p")
	WebElement priceElement1;

	@FindBy(xpath = "//*[@id=\"product-1\"]/td[4]/button")
	WebElement quantityElement;

	@FindBy(xpath = "//*[@id=\"product-2\"]/td[4]/button")
	WebElement quantityElement1;

	@FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/button")
	WebElement clickAddCartElement2;

	@FindBy(xpath = "//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a/u")
	WebElement clickViewCartElement1;

	@FindBy(xpath = "//*[@id=\"product-1\"]/td[4]/button")
	WebElement quantityIncreaseElement;//*[@id="quantity"]
	

	@FindBy(xpath = "//*[@id=\"cart_items\"]/div/div[1]/ol/li[2]")
	WebElement shoppingCartPgaeElement;
	

	@FindBy(xpath = "//*[@id=\"product-1\"]/td[6]")
	WebElement clickItemRemoveElement;
	

	@FindBy(xpath = "//*[@id=\"cart_items\"]/div/div[1]/ol/li[2]")
	WebElement cartIsEmptyElement;
	
	@FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div/div[2]/div/div[1]/div[1]/a")
	WebElement clickAddCartElement3;

	
//	@FindBy(xpath = "//*[@id=\"empty_cart\"]/p/b")
//	WebElement cartIsEmptyElement;
	

	public AddProductPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void clickAddCart() {
		clickAddCartElement.click();
		clickContinueElement.click();
		clickAddCartElement1.click();
		clickViewCartElement.click();
	}

	public String priceText() {
		String getPrice = priceElement.getText();
		return getPrice;
	}

	public String priceText1() {
		String getPrice = priceElement1.getText();
		return getPrice;
	}

	public String quantityText() {
		String getPrice = quantityElement.getText();
		return getPrice;
	}

	public String quantityText1() {
		String getPrice = quantityElement1.getText();
		return getPrice;
	}

	public void addCart() {
		clickAddCartElement2.click();
	}

	public void clickViewCart() {
		clickViewCartElement1.click();
	}

	public String quantityIncreaseElement() {
		String getPrice = quantityIncreaseElement.getText();
		return getPrice;
	}
	public String getShoppingCartText() {
		String shoppingCartText = shoppingCartPgaeElement.getText();
		return shoppingCartText;
	}
	
	public void clickItemRemove() {
		clickItemRemoveElement.click();
	}
	
	public String getEmptyCartTexts() {
		String emptyCartTexts = cartIsEmptyElement.getText();
		return emptyCartTexts;
	}
	public void addCart1() {
		clickAddCartElement3.click();
	}
}