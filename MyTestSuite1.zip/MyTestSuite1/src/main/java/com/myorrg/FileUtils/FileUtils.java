package com.myorrg.FileUtils;

import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;

public class FileUtils {

	public static void main(String[] args) throws IOException, InterruptedException {
		Properties props = null;
		FileUtils fileUtilsObj = new FileUtils();
		props = fileUtilsObj.getProperties("automation.properties");
		String baseUrl = props.getProperty("Base_URL");
		System.out.println(baseUrl);
	}

	public Properties getProperties(String filename) throws IOException, InterruptedException {
		String filePath = "C:\\java work space\\MyTestSuite1\\src\\main\\resources";

		String file = filePath + filename;
		System.err.println("file : " + file);
		FileReader reader = new FileReader("file");
		Properties pros = new Properties();
		pros.load(reader);
		return pros;

//	 System.setProperty("webdriver.chrome.driver", "C:\\ChromeDriver\\138\\chromedriver.exe");
//		ChromeDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.get(pros.getProperty("serachTerm"));
//		driver.get("https://automationexercise.com/test_cases");
//		Thread.sleep(2000);
//		driver.close();
	}
}