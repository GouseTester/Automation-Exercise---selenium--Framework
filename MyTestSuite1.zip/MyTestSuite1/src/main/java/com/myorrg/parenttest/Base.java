package com.myorrg.parenttest;

import java.time.Duration;

import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class Base extends FeedTest {
	private WebDriver driver;

	@BeforeSuite
	public void init() {
		System.out.println("@BeforeSuite  initBase");
		System.setProperty("webdriver.chrome.driver", "C:\\ChromeDriver\\138\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		// driver.get("https://www.tutorialspoint.com/selenium/practice/login.php");
		driver.get("https://automationexercise.com/test_cases");
		//driver.get("https://automationexercise.com");
	}

	public WebDriver getdriver() {
		return driver;
	}

	@AfterSuite
	public void destroy() {
		// if(driver!=null);
		driver.quit();
		System.out.println("@AfterSuite ");
	}

}
