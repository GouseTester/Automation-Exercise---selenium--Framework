package com.myorrg.AutomationPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoggedPage {

	WebDriver driver;
	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div/div/a")
	WebElement continueElement;

	@FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[10]/a")
	WebElement loggedElement;
	

	
	public LoggedPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void verifyContinue() {
		continueElement.click();
	}
	

	public String getLoggedText() {
		String loggedText = loggedElement.getText();
		return loggedText;
		
	}

}
