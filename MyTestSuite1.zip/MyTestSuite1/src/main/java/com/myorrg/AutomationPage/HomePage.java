package com.myorrg.AutomationPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	WebDriver driver;
	
	@FindBy(xpath = "//*[@id=\"form\"]/div/div[1]/div/h2/b")
	WebElement homeTextElement;

	@FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")
	WebElement loginbtnElement;


	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public String getHeaderText() {
		String homePage = homeTextElement.getText();
		return homePage;
	}

	public void clickLoginBtn() {
		loginbtnElement.click();
	}
}


