package com.myorrg.SubscriptionPage;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SubscriptionHomePage {
	WebDriver driver;

	@FindBy(xpath = "//*[@id=\"footer\"]/div[1]/div/div/div[2]/div/h2")
	WebElement subscriptionElement;

	@FindBy(xpath = "//*[@id=\"susbscribe_email\"]")
	WebElement emailElement;

	@FindBy(xpath = "//*[@id=\"subscribe\"]")
	WebElement submitElement;

	@FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")
	WebElement clickCartElement;

	@FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div[2]/h2")
	WebElement recommendedProductsElement;

	@FindBy(xpath = "//*[@id=\"recommended-item-carousel\"]/div/div[1]/div[1]/div/div/div/a")
	WebElement recommendedCartElement;

	@FindBy(xpath = "//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a/u")
	WebElement recommendedViewCartElement;

	@FindBy(xpath = "//*[@id=\"product-1\"]/td[2]/h4/a")
	WebElement recommendedCartTextElement;

	@FindBy(xpath = "//*[@id=\"scrollUp\"]")
	WebElement clickUpArrowElement;

	@FindBy(xpath = "//*[@id=\"slider-carousel\"]/div/div[1]/div[1]/h2")
	WebElement fullpageTextElement;

	public SubscriptionHomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public String subscriptionText() {
		String getSubscriptionText = subscriptionElement.getText();
		return getSubscriptionText;
	}

	public void scrollToFooter() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", subscriptionElement);

	}

	public void clickEmail() {
		emailElement.sendKeys("gousebhai81@gmail.com");
		submitElement.click();
	}

	public void clickCart() {
		clickCartElement.click();
	}

	public void scrollToRecommended() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", subscriptionElement);

	}

	public String getRecommendedProductsText() {
		String getRecommendedText = recommendedProductsElement.getText();
		return getRecommendedText;
	}

	public void clickRecommendedCartView() {
		recommendedCartElement.click();
		recommendedViewCartElement.click();
	}

	public String getRecommendedCartText() {
		String recommendedCartText = recommendedCartTextElement.getText();
		return recommendedCartText;
	}

	public void clickUparrow() {
		clickUpArrowElement.click();
	}

	public String getFullPageText() {
		String fullPageText = fullpageTextElement.getText();
		return fullPageText;

	}
	public void scrollToTopPage() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", fullpageTextElement);

	}

}
