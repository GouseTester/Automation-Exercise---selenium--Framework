package com.myorrg.UserPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AutomationLoginPage {
	WebDriver driver;
	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div[1]/div/h2")
	WebElement loginAccountVisibleElement;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div[1]/div/form/input[2]")
	WebElement emailTextElement;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div[1]/div/form/input[3]")
	WebElement passwordTextElement;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div[1]/div/form/button")
	WebElement loginElement;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div[1]/div[1]/form/p")
	WebElement invalidPasswordElement;

	public AutomationLoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public String loginHeaderText() {
		String loginUser = loginAccountVisibleElement.getText();
		return loginUser;
	}

	public void signUp(String email, String password) {
	    emailTextElement.sendKeys(email);
		passwordTextElement.sendKeys(password);
		loginElement.click();
	}

	public String wrongDetails() {
		String invalidDetails = invalidPasswordElement.getText();
		return invalidDetails;
	}
}
