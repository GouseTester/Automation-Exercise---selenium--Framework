package com.ui.PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageFactoryRegister {
	WebDriver driver;
	@FindBy(xpath = "//*[@id=\"signupForm\"]/h1")
	WebElement text;
	
	@FindBy(xpath = "//*[@id=\"firstname\"]")
	WebElement firstNameElement;
	
	@FindBy(xpath = "//*[@id=\"lastname\"]")
	WebElement lastnameElement;
	
	@FindBy(xpath = "//*[@id=\"username\"]")
	WebElement userElement;
	
	@FindBy(xpath = "//*[@id=\"password\"]")
	WebElement passwordElement;
	
	public PageFactoryRegister(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public String verifyRegisterPage() {
		String registerText = text.getText();
		return registerText;	
	}
	
	public String verifyFirstName() {
		String fisrtName = firstNameElement.getText();
		return fisrtName;	
	}
	public String verifyLastName() {
		String lastName = lastnameElement.getText();
		return lastName;	
	}
	public String verifyUserName() {
		String userName = userElement.getText();
		return userName;	
		}	
	
	public String verifyPassword() {
		String password = passwordElement.getText();
		return password;	
	}

}
