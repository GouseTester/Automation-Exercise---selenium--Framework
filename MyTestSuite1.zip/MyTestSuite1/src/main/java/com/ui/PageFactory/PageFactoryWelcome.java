package com.ui.PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageFactoryWelcome {
	WebDriver driver;
	@FindBy(xpath = "//*[@id='signInForm']/h1")
	WebElement text;

	@FindBy(xpath = "//*[@id=\"email\"]")
	WebElement usereName;

	@FindBy(xpath = "//*[@id=\"password\"]")
	WebElement password;

	@FindBy(xpath = "//*[@id=\"signInForm\"]/div[3]/a")
	WebElement btn;

	public PageFactoryWelcome(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public String verifyPageHeading() {
		String headText = text.getText();
		return headText;
	}

	public String verifyUserName() {
		String userText = usereName.getText();
		return userText;
	}

	public String verifyPassword() {
		String passwordText = password.getText();
		return passwordText;
	}

	public void clickNewUser() {
		btn.click();
	}
}
