package com.ui.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegisterPageObject {
	WebDriver driver;
	By text = By.xpath("//*[@id=\"signupForm\"]/h1");
	By FirstName = By.xpath("//*[@id=\"firstname\"]");
	By LastName = By.xpath("//*[@id=\"lastname\"]");
	By userName = By.xpath("//*[@id=\"username\"]");
	By password = By.xpath("//*[@id=\"password\"]");

	public RegisterPageObject(WebDriver driver) {
		this.driver = driver;
	}

	public String verifyRegisterPage() {
		String RegisterHeadText = driver.findElement(text).getText();
		return RegisterHeadText;
	}

	public String Firstname() {
		String firstname = driver.findElement(FirstName).getText();
		return firstname;

	}

	public String Lastname() {
		String lastname = driver.findElement(LastName).getText();
		return lastname;

	}

	public String UserName() {
		String username = driver.findElement(userName).getText();
		return username;
	}

	public String password() {
		String Password = driver.findElement(password).getText();
		return Password;
	}

}
