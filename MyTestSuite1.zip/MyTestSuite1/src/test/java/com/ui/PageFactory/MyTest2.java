package com.ui.PageFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myorrg.parenttest.Base;

public class MyTest2 extends Base {
	WebDriver driver;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		System.out.println("@!Before Test driver");
	}

	public String newUserText(WebDriver driver) {
		WebElement ClickNewUser = driver.findElement(By.xpath("//*[@id=\"signInForm\"]/div[3]/a"));
		String newUser = ClickNewUser.getText();
		return newUser;

	}

	@Test
	public void UserText() {
		String actual = newUserText(driver);
		String expected = "New User";
		Assert.assertEquals(actual, expected);
		System.out.println("finish Test");
	}

}
