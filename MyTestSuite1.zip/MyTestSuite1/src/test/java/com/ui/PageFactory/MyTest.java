package com.ui.PageFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myorrg.parenttest.Base;

public class MyTest extends Base {
	WebDriver driver;

	@BeforeTest
	public void initilization() {
		driver = getdriver();
		System.out.println("@BeforeTest initialization");
	}

	public String getheadertext(WebDriver driver) {
		WebElement element = driver.findElement(By.xpath("//*[@id=\"signInForm\"]/h1"));
		String headerText = element.getText();
		return headerText;

	}

	@Test(priority = 1)
	public void  HeadingText() {
		String actualheadertext = getheadertext(driver);
		String expectedheadertext = "Welcome, Login In";
		Assert.assertEquals(actualheadertext, expectedheadertext);

	}
}
