package com.myorrg.AutomationContactTest;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myorrg.AutomationContactPage.ContactSuccessTestPage;
import com.myorrg.AutomationContactPage.ContactTestPage;
import com.myorrg.AutomationPage.HomePage;
import com.myorrg.parenttest.Base;

public class ContactUsTest extends Base {

	WebDriver driver;
	HomePage homePageObj;
	ContactTestPage contactTestPageObj;
	ContactSuccessTestPage contactSuccessTestPageObj;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		contactTestPageObj = new ContactTestPage(driver);
		contactSuccessTestPageObj = new ContactSuccessTestPage(driver);
	}

	@Test(priority = 1, dataProvider = "feeder")
	@Source("\\ContactData\\ContactUsPage.csv")
	public void homePage(String homeHeaderText, String contactHeaderText, String name, String email, String subject,
			String message, String contactSuccessText) {
		String hedaerText = homePageObj.getHeaderText();
		System.out.println("hedaerText :" + hedaerText);
		assertEquals(hedaerText, homeHeaderText, "Actual and Excepted Value are Same");
		contactTestPageObj.clickContactUs();

		String ContactHedaerText = contactTestPageObj.getContactHeaderText();
		System.out.println("ContactHedaerText :" + ContactHedaerText);
		assertEquals(ContactHedaerText, contactHeaderText, "Actual and Excepted Value are Same");
		contactTestPageObj.fillDetails(name, email, subject, message);

		contactTestPageObj.fileUpload();
	}
}

// contactTestPageObj.alertText();
//		contactTestPageObj.alert();
//		String successHeaderText = contactSuccessTestPageObj.getSuccessHeaderText();
//		System.out.println("successHeaderText :" + successHeaderText);
//		assertEquals(successHeaderText, contactSuccessText, "Actual and Excepted Value are Same");

//	@Test(priority = 2, dataProvider = "feeder")
//	@Source("\\ContactData\\ContactUsPage.csv")
//	public void contactPage(String name, String email, String subject, String message, String contactSuccessText) {
//		String hedaerText = contactTestPageObj.getContactHeaderText();
//		System.out.println("hedaerText :" + hedaerText);
//		contactTestPageObj.fillDetails(name, email, subject, message, exceptedValue);
//		assertEquals(hedaerText, exceptedValue, "Actual and Excepted Value are Same");
//		contactTestPageObj.fileUpload();
//		contactTestPageObj.alertText();
//		contactTestPageObj.alert();

//	@Test(priority = 3, dataProvider = "feeder")
//	@Source("\\ContactData\\ContactSuccessPage.csv")
//	public void contactSuccessPage(String tcId, String tcDescription, String exceptedValue)  {
//
//	
//		String hedaerText1 = contactSuccessTestPageObj.getSuccessHeaderText();
//		System.out.println("hedaerText1 :" + hedaerText1);
//		assertEquals(hedaerText1, exceptedValue, "Actual and Excepted Value are Same");
//		contactSuccessTestPageObj.clickHome();
//	}
