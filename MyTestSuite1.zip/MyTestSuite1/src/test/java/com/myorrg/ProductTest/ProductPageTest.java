package com.myorrg.ProductTest;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myorrg.AutomationPage.HomePage;
import com.myorrg.ProductsPage.AllProductPage;
import com.myorrg.ProductsPage.ViewProductPage;
import com.myorrg.parenttest.Base;

public class ProductPageTest extends Base {
	WebDriver driver;
	HomePage homePageObj;
	AllProductPage allProductPageObj;
	ViewProductPage viewProductPageObj;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		allProductPageObj = new AllProductPage(driver);
		viewProductPageObj = new ViewProductPage(driver);
	}

	@Test(priority = 1, dataProvider = "feeder")
	@Source("\\ProductFile\\ProductPageFile.csv")
	public void homePage(String homeHeaderText, String productPagetext, String ProductName, String productCategory,
			String productPrice, String productAvailability, String productCondition, String productBrand) {
		String getHeaderText = homePageObj.getHeaderText();
		System.out.println("getHeaderText : " + getHeaderText);
		assertEquals(getHeaderText, homeHeaderText);
		allProductPageObj.clickproduct();
		String getProductText = allProductPageObj.productPage();
		System.out.println("getProductText : " + getProductText);
		assertEquals(getProductText, productPagetext);

		allProductPageObj.ViewProduct();

		String getNameText = viewProductPageObj.nameDetails();
		System.out.println("getNameText : " + getNameText);
		assertEquals(getNameText, ProductName);

		String getcategoryText = viewProductPageObj.categoryDetails();
		System.out.println("getcategoryText : " + getcategoryText);
		assertEquals(getcategoryText, productCategory);

		String getpriceText = viewProductPageObj.priceDetails();
		System.out.println("getpriceText : " + getpriceText);
		assertEquals(getpriceText, productPrice);

		String getavailabilityText = viewProductPageObj.availabilityDetails();
		System.out.println("getavailabilityText : " + getavailabilityText);
		assertEquals(getavailabilityText, productAvailability);

		String getconditionText = viewProductPageObj.conditionDetails();
		System.out.println("conditionPage : " + getconditionText);
		assertEquals(getconditionText, productCondition);

		String getbrandText = viewProductPageObj.brandDetails();
		System.out.println("conditionPage : " + getbrandText);
		assertEquals(getbrandText, productBrand);
	}
}
