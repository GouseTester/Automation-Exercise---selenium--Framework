package com.myorrg.AutomationPageTEst;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myorrg.AutomationPage.AccountCreationPage;
import com.myorrg.AutomationPage.DeleteAccountPage;
import com.myorrg.AutomationPage.HomePage;
import com.myorrg.AutomationPage.LoggedPage;
import com.myorrg.AutomationPage.LoginPage;
import com.myorrg.parenttest.Base;

public class RegisterUserTest extends Base {
	WebDriver driver;
	HomePage homePageObj;
	LoginPage loginPageObj;
	AccountCreationPage accountCreationPageObj;
	LoggedPage loggedPageObj;
	DeleteAccountPage deleteAccountPageObj;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		loginPageObj = new LoginPage(driver);
		accountCreationPageObj = new AccountCreationPage(driver);
		loggedPageObj = new LoggedPage(driver);
		deleteAccountPageObj = new DeleteAccountPage(driver);
	}

	@Test(priority = 1, dataProvider = "feeder")
	@Source("\\FilesData\\DesktopFile.CSV")
	public void homePage(String id, String description, String exceptedValue) {
		System.out.println("id is : " + id);
		System.out.println("description is : " + description);
		System.out.println("exceptedValue is : " + exceptedValue);
		String headerText = homePageObj.getHeaderText();
		System.out.println("text is : " + headerText);
		assertEquals(headerText, exceptedValue, "Actual and Excepted are same");

	}

	@Test(priority = 2, dataProvider = "feeder")
	@Source("\\FilesData\\NewUserPage.csv")
	public void newUserPage(String id, String description, String exceptedValue) {
		System.out.println("id is : " + id);
		System.out.println("description is : " + description);
		System.out.println("exceptedValue is : " + exceptedValue);
		homePageObj.clickLoginBtn();
		String newUserHeaderText = loginPageObj.newUserSignUpHeader();
		System.out.println("UserPage is : " + newUserHeaderText);
		assertEquals(newUserHeaderText, exceptedValue, "Actual and Excepted are same");

	}

	@Test(priority = 3, dataProvider = "feeder")
	@Source("\\FilesData\\AccountPage.csv")
	public void information(String id, String description, String exceptedValue, String name, String emailId) {
		System.out.println("id is : " + id);
		System.out.println("description is : " + description);
		System.out.println("exceptedValue is : " + exceptedValue);
		loginPageObj.signUpUser(name, emailId);

		String accountInfoText = loginPageObj.accountInfoHeader();
		System.out.println("CreatedPage : " + accountInfoText);
		assertEquals(accountInfoText, exceptedValue, "Actual and Excepted are same");

	}

	@Test(priority = 4, dataProvider = "feeder")
	@Source("\\FilesData\\AccountCreated.csv")
	public void accontDisplayed(String id, String description, String exceptedValue, String password, String firstName,
			String lastName, String company, String address1, String address2, String state, String city,
			String zipCode, String mobileNumber) {
		System.out.println("id is : " + id);
		System.out.println("description is : " + description);
		System.out.println("exceptedValue is : " + exceptedValue);
		System.out.println("firstName is : " + firstName);
		accountCreationPageObj.fillAccountDetails(password, firstName, lastName, company, address1, address2, state,
				city, zipCode, mobileNumber);
		accountCreationPageObj.clickCreateAccountBtn();
		String accountCreationHeaderText = accountCreationPageObj.accountCreationHeader();
		System.out.println("accountCreationHeaderText : " + accountCreationHeaderText);
		assertEquals(accountCreationHeaderText, exceptedValue, "Actual and Excepted are same");

	}

	@Test(priority = 5, dataProvider = "feeder")
	@Source("\\FilesData\\LoggedPage.csv")
	public void loggedPage(String tcId, String tcDescription, String exceptedValue) {
		System.out.println("tcId is : " + tcId);
		System.out.println("description is : " + tcDescription);
		System.out.println("exceptedValue is : " + exceptedValue);
		loggedPageObj.verifyContinue();
		
		String loggedHeaderText = loggedPageObj.getLoggedText();
		System.out.println("loggedHeaderText : " + loggedHeaderText);
		assertEquals(loggedHeaderText, exceptedValue, "Actual and Excepted are same");

	}

	@Test(priority = 6, dataProvider = "feeder")
	@Source("\\FilesData\\DeletedPage.csv")
	public void deletePage(String tcId, String tcDescription, String exceptedValue){
		System.out.println("tcId is : " + tcId);
		System.out.println("description is : " + tcDescription);
		System.out.println("exceptedValue is : " + exceptedValue);
		deleteAccountPageObj.clickDelete();
		String deletedHeaderText = deleteAccountPageObj.accountDeleted();
		System.out.println("deletedHeaderText : " + deletedHeaderText);
		assertEquals(deletedHeaderText, exceptedValue, "Actual and Excepted are same");
deleteAccountPageObj.clickContinue();
	}
	
}
