package com.myorrg.SearchProductTest;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myorrg.AutomationPage.HomePage;
import com.myorrg.ProductsPage.AllProductPage;
import com.myorrg.SearchProductPage.ProductSearchPage;
import com.myorrg.parenttest.Base;

public class SearchProductTest extends Base {

	WebDriver driver;
	HomePage homePageObj;
	AllProductPage allProductPageObj;

	ProductSearchPage productSearchPageObj;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		allProductPageObj = new AllProductPage(driver);

		productSearchPageObj = new ProductSearchPage(driver);
	}

	@Test(priority = 1, dataProvider = "feeder")
	@Source("\\SearchProductFile\\SearchProductFile.csv")
	public void homePage(String homeHeaderText, String productPagetext, String searchedProductsText) {
		String getHeaderText = homePageObj.getHeaderText();
		System.out.println("getHeaderText : " + getHeaderText);
		assertEquals(getHeaderText, homeHeaderText);

		allProductPageObj.clickproduct();
		String getProductText = allProductPageObj.productPage();
		System.out.println("getProductText : " + getProductText);
		assertEquals(getProductText, productPagetext);

		productSearchPageObj.clickSearch();
		String getSearchProductText = productSearchPageObj.searcheTestdPage();
		System.out.println("getSearchProductText : " + getSearchProductText);
		assertEquals(getSearchProductText, searchedProductsText);

	}

}
