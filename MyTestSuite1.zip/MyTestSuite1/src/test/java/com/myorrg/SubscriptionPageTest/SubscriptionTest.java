package com.myorrg.SubscriptionPageTest;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myorrg.AutomationPage.HomePage;
import com.myorrg.SubscriptionPage.SubscriptionHomePage;
import com.myorrg.parenttest.Base;

public class SubscriptionTest extends Base {
	WebDriver driver;
	HomePage homePageObj;
	SubscriptionHomePage subscriptionHomePageObj;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		subscriptionHomePageObj = new SubscriptionHomePage(driver);
	}

	@Test(priority = 1, dataProvider = "feeder")
	@Source("SubscriptionFile\\SubscriptionFile.csv")
	public void homePage(String homeHeaderText, String subscriptionText, String subscribedText) {
		String getHeaderText = homePageObj.getHeaderText();
		System.out.println("getHeaderText : " + getHeaderText);
		assertEquals(getHeaderText, homeHeaderText);

		subscriptionHomePageObj.clickCart();
		subscriptionHomePageObj.scrollToFooter();
		subscriptionHomePageObj.clickEmail();

		String getsubscriptionText = subscriptionHomePageObj.subscriptionText();
		subscriptionHomePageObj.scrollToFooter();
		System.out.println("getHeaderText : " + getsubscriptionText);
		assertEquals(getsubscriptionText, subscriptionText);
	}
}