package com.myorrg.api;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BookStoreDeleteTest {
	@Test
	public void DeleteBooks() {
		RestAssured.baseURI = "https://demoqa.com/BookStore/v1/Books";
		RequestSpecification httpRequest = RestAssured.given();
		Response response  = httpRequest.queryParam("isbn", "9781449325862").request(Method.DELETE);
		 String ResponseData = response.asPrettyString();
		 System.out.println(" ResponseData :" + ResponseData);
		 System.out.println("Status received :"+ response.getStatusCode());
		 int actualCode = response.getStatusCode();
		 int excepetedcode = 401;
		 
		 Assert.assertEquals(actualCode, excepetedcode);

	}

}
