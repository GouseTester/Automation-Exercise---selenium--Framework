package com.myorrg.api;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BookStoreDeleteBookTest {
	@Test
	public void getBook() {
		RestAssured.baseURI = "https://demoqa.com/BookStore/v1/Book";
		String requestBody = """
				{
				"isbn" : "9781449325862",
				 "UserId": "293854ba-a336-453f-9b3d-10ac19868bc1@"

				}
				""";

		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.DELETE);
		System.out.println("response : "+response.asPrettyString());
		System.out.println("Status received : "+response.getStatusCode());
		 int actualCode = response.getStatusCode();
		 int excepetedcode = 401;
		 
		 Assert.assertEquals(actualCode, excepetedcode);
	}
}