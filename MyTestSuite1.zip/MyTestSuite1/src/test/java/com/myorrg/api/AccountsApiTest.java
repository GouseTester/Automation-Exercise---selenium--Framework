package com.myorrg.api;

import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class AccountsApiTest {
	@Test
	public void createUser() {
		RestAssured.baseURI = "https://demoqa.com/Account/v1/User";
		String requestBody = """
				   {
						   "userName": "Gouse81@",
							"password": "Gouse81@"
				   }
				""";
		
		RequestSpecification httpRequest = RestAssured.given();

		Response response = httpRequest.headers("Content-Type", "application/json").body(requestBody).request(Method.POST);
//				.header("Content-Type", "application/json")
//				.body(requestBody)
//				.when()
//				.post("/Account/v1/User");

		// Response response = httpRequest.request(Method.POST);
		System.out.println("status received :" + response.getStatusLine());
		System.out.println("response :" + response.prettyPrint());

	}
}
