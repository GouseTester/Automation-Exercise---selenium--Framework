package com.myorrg.api;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteuuidTest {
	@Test
	public void userUuid() {
		 String UserId = "3e59480c-c8b9-4d0c-b381-e03e909eec5c";

		RestAssured.baseURI = "https://demoqa.com/Account/v1/User";

		Response response =RestAssured.given()
				//.header("Content-type", "application/json")
				.delete("/Account/v1/User/"+ UserId);
//		RequestSpecification httpRequest = RestAssured.given();
//		RequestSpecification httpRequest = RestAssured.given();
//
//		Response response = httpRequest.request(Method.DELETE+UserId);
		/// Account/v1/User/
		//RequestSpecification httpRequest = RestAssured.given();
		// Response response = httpRequest.request(Method.DELETE);
		System.out.println("response : " + response.statusCode());
		System.out.println("response : " + response.prettyPrint());

	}
}
