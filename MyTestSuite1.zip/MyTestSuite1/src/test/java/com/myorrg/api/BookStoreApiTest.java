package com.myorrg.api;

import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.myorrg.parenttest.Base;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BookStoreApiTest extends Base {
	@Test
	public void getBookDetails() {
		
		RestAssured.baseURI = "https://demoqa.com/BookStore/v1/Books";	
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		System.out.println("status received :"+response.getStatusLine());
		//System.out.println("response :"+ response.prettyPrint());
		
		String responseData = response.asString();
		System.out.println(responseData);
//		Gson gson = new Gson();
//		JsonObject jsonObject = gson.fromJson(responseData, JsonObject.class);
//		System.out.println(jsonObject);
//		System.out.println(jsonObject.get("books"));
//		
	}
}
