package com.myorrg.api;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ApiDetails {
	
	@Test(priority = 1)
	public void GetWeatherDetailsCondensed() {
		RestAssured.baseURI = "https://demoqa.com/BookStore/v1/Books";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET, "");
		System.out.println("Status received => " + response.getStatusLine());
		System.out.println("Response=>" + response.prettyPrint());

	}
	@Test(priority = 2)
	public void GetWeatherDetailsCondensed1() {
		RestAssured.baseURI = "https://demoqa.com/BookStore/v1/Books";
		RequestSpecification httpRequest2 = RestAssured.given();
		Response response2 = httpRequest2.request(Method.GET, "");
		int exceptedStatusCode = 200;
		int actualStatusCode = response2.getStatusCode();


		Assert.assertEquals(exceptedStatusCode, actualStatusCode,"Actual and Excepted Same");

	}

}
