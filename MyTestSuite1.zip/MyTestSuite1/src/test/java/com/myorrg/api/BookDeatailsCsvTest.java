package com.myorrg.api;

import org.databene.benerator.anno.Source;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.myorrg.parenttest.Base;

import io.restassured.response.Response;

import io.restassured.RestAssured;
import io.restassured.http.Method;

public class BookDeatailsCsvTest extends Base {
	// BookDeatailsCsvTest bookDeatailsCsvTestObj = new BookDeatailsCsvTest();

	@BeforeTest
	public void BookDetails() {
		RestAssured.baseURI = "https://demoqa.com/BookStore/v1/Book";
	}

	@Test(dataProvider = "feeder")
	@Source("\\BooksApiFile\\BooksFile.csv")
	public void BookDetails1(String expectedIsbn, String expectedTitle, String expectedSubTitle, String expectedAuthor,
			String expectedPublishDate, String expectedPublisher, String expectedPages, String expectedWebsite) {

		System.out.println("expectedIsbn :" + expectedIsbn);

		Response response = RestAssured.given().queryParam("ISBN", "9781449325862").request(Method.GET);

		String responseData = response.asPrettyString();
		System.out.println("responseData : " + responseData);
		JsonObject jsonObject = new Gson().fromJson(responseData, JsonObject.class);
		System.out.println(jsonObject);

		Assert.assertEquals(jsonObject.get("isbn").getAsString(), expectedIsbn);
		Assert.assertEquals(jsonObject.get("title").getAsString(), expectedTitle);
		Assert.assertEquals(jsonObject.get("subTitle").getAsString(), expectedSubTitle);
		Assert.assertEquals(jsonObject.get("author").getAsString(), expectedAuthor);
		Assert.assertEquals(jsonObject.get("publish_date").getAsString(), expectedPublishDate);
		Assert.assertEquals(jsonObject.get("publisher").getAsString(), expectedPublisher);
		Assert.assertEquals(jsonObject.get("pages").getAsString(), expectedPages);
		Assert.assertEquals(jsonObject.get("website").getAsString(), expectedWebsite);

	}

}
