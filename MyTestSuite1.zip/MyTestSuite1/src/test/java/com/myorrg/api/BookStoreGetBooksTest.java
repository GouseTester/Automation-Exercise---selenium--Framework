package com.myorrg.api;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BookStoreGetBooksTest {
	@Test
	public void GetBooks() {
		RestAssured.baseURI = "https://demoqa.com/BookStore/v1/Books";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		//System.out.println("status received :"+response.getStatusLine());

		String ResponseData = response.prettyPrint();
		System.out.println("ResponseData : "+ResponseData);

		
	}

}
