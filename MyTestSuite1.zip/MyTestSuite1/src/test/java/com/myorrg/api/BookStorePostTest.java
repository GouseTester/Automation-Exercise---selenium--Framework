package com.myorrg.api;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BookStorePostTest {
	@Test
	public void PostBooks() {
		RestAssured.baseURI = "https://demoqa.com/BookStore/v1/Books";
		
		
		String requestBody = """
				{
				  "UserId": "293854ba-a336-453f-9b3d-10ac19868bc1@",
				  "books": [
				  {
				  "isbn" : "9781449325862"
				}
				""";
		System.out.println(requestBody);
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		System.out.println("Status received : "+response.statusCode());
		System.out.println("Response Data : "+response.asPrettyString());
int actualCode = response.getStatusCode();
int exceptedCode = 200;
Assert.assertEquals(actualCode, exceptedCode);
		
	}

}
