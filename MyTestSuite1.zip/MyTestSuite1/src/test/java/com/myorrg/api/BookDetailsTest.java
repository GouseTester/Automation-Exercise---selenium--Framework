package com.myorrg.api;

import org.databene.benerator.anno.Source;
import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class BookDetailsTest {
	@Test(priority =1)
	@Source("\\BooksApiFile\\BooksFile.csv")
	public void bookDetails() {

		String exceptedIsbn = "9781449325862";
		String exceptedtitle = "Git Pocket Guide";
		String exceptedsubTitle = "A Working Introduction";
		String exceptedAuthor = "Richard E. Silverman";
		String exceptedPublishDate = "2020-06-04T08:48:39.000Z";
		String exceptedPublisher = "O'Reilly Media";
		String exceptedPages = "234";
		String exceptedWebsite = "http://chimera.labs.oreilly.com/books/1230000000561/index.html";

		RestAssured.baseURI = "https://demoqa.com/BookStore/v1/Book";

		Response response = RestAssured.given().queryParam("ISBN", "9781449325862").request(Method.GET);

		String responseData = response.asString();
		JsonObject jsonObject = new Gson().fromJson(responseData, JsonObject.class);
		System.out.println(jsonObject);

		String getIsbn = jsonObject.get("isbn").getAsString();
		System.out.println("getIsbn : " + getIsbn);
		Assert.assertEquals(getIsbn, exceptedIsbn);

		String getTitle = jsonObject.get("title").getAsString();
		System.out.println("getTitle : " + getTitle);
		Assert.assertEquals(getTitle, exceptedtitle);

		String getSubtitle = jsonObject.get("subTitle").getAsString();
		System.out.println("getSubtitle : " + getSubtitle);
		Assert.assertEquals(getSubtitle, exceptedsubTitle);

		String getAuthor = jsonObject.get("author").getAsString();
		System.out.println("getAuthor : " + getAuthor);
		Assert.assertEquals(getAuthor, exceptedAuthor);

		String getPublishDate = jsonObject.get("publish_date").getAsString();
		System.out.println("getPublishDate : " + getPublishDate);
		Assert.assertEquals(getPublishDate, exceptedPublishDate);

		String getpublisher = jsonObject.get("publisher").getAsString();
		System.out.println("getpublisher : " + getpublisher);
		Assert.assertEquals(getpublisher, exceptedPublisher);

		String getpages = jsonObject.get("pages").getAsString();
		System.out.println("getpages : " + getpages);
		Assert.assertEquals(getpages, exceptedPages);

		String getWebsite = jsonObject.get("website").getAsString();
		System.out.println("getWebsite : " + getWebsite);
		Assert.assertEquals(getWebsite, exceptedWebsite);

	}
}
