package downloadInvoiceTest;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myoor.AutomationTestCasesPage.MainTestCasesPage;
import com.myoor.PlaceOrderPage.PlaceOrderPage;
import com.myorrg.AddProduct.AddProductPage;
import com.myorrg.AutomationPage.AccountCreationPage;
import com.myorrg.AutomationPage.HomePage;
import com.myorrg.AutomationPage.LoggedPage;
import com.myorrg.AutomationPage.LoginPage;
import com.myorrg.ProductsPage.AllProductPage;
import com.myorrg.UserPage.AutomationLoginPage;
import com.myorrg.parenttest.Base;

public class DownloadInvoiceTest extends Base {
	WebDriver driver;
	HomePage homePageObj;
	AutomationLoginPage automationLoginPageObj;
	MainTestCasesPage mainTestCasesPageObj;
	AddProductPage addProductPageObj;
	PlaceOrderPage placeOrderPageObj;
	LoginPage loginPageObj;
	AccountCreationPage accountCreationPageObj;
	LoggedPage loggedPageObj;
	AllProductPage allProductPageObj;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		automationLoginPageObj = new AutomationLoginPage(driver);
		mainTestCasesPageObj = new MainTestCasesPage(driver);
		addProductPageObj = new AddProductPage(driver);
		placeOrderPageObj = new PlaceOrderPage(driver);
		loginPageObj = new LoginPage(driver);
		accountCreationPageObj = new AccountCreationPage(driver);
		loggedPageObj = new LoggedPage(driver);
		allProductPageObj = new AllProductPage(driver);

	}

	@Test(priority = 1, dataProvider = "feeder")
	@Source("\\downloadInvoiceFile\\DownloadInvoiceFile.csv")
	public void homePage(String homeHeaderText, String name, String emailid, String password, String firstName,
			String lastName, String company, String address1, String address2, String state, String city,
			String zipCode, String mobileNumber, String accCreatedHeaderText, String loggedHeaderText,
			String deliveryAddress, String reviewText, String sendDescription, String nameOnCard, String cardNumber,
			String cvvNumber, String expiryMonth, String expiryYear, String orderPlacedText) {
		String getHeaderText = homePageObj.getHeaderText();
		System.out.println("getHeaderText : " + getHeaderText);
		assertEquals(getHeaderText, homeHeaderText);
		
		mainTestCasesPageObj.clickHome();
		addProductPageObj.addCart1();
		addProductPageObj.clickViewCart();

		placeOrderPageObj.checkOut();
		placeOrderPageObj.clickRegister();

		loginPageObj.signUpUser(name, emailid);

		loginPageObj.accountInfoHeader();

		accountCreationPageObj.fillAccountDetails(password, firstName, lastName, company, address1, address2, state,
				city, zipCode, mobileNumber);

		accountCreationPageObj.clickCreateAccountBtn();

		String accountCreationHeaderText = accountCreationPageObj.accountCreationHeader();
		System.out.println("accountCreationHeaderText : " + accountCreationHeaderText);
		assertEquals(accountCreationHeaderText, accCreatedHeaderText, "Actual and Excepted are same");
		
		loggedPageObj.verifyContinue();

		String getloggedHeaderText = loggedPageObj.getLoggedText();
		System.out.println("getloggedHeaderText : " + getloggedHeaderText);
		assertEquals(getloggedHeaderText, loggedHeaderText, "Actual and Excepted are same");
		
		placeOrderPageObj.clickCart();
		placeOrderPageObj.checkOut();
		
		String gettAddressText = placeOrderPageObj.getDeliveryAddress();
		System.out.println("gettAddressText : " + gettAddressText);
		assertEquals(gettAddressText, deliveryAddress, "Actual and Excepted are same");

		String getReviewText = allProductPageObj.getReviewText();
		System.out.println("getReviewText : " + getReviewText);
		assertEquals(getReviewText, reviewText, "Actual and Excepted are same");
		placeOrderPageObj.sendDescription(sendDescription);

		placeOrderPageObj.paymentDetails(nameOnCard, cardNumber, cvvNumber, expiryMonth, expiryYear);

		String getSuccessText = placeOrderPageObj.getSuccessText();
		System.out.println("getSuccessText : " + getSuccessText);
		assertEquals(getSuccessText, orderPlacedText, "Actual and Excepted are same");
		
		placeOrderPageObj.clickDownloadInvoice();
	}
}
