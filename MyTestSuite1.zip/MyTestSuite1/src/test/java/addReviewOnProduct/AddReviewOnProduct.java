package addReviewOnProduct;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myorrg.AutomationPage.HomePage;
import com.myorrg.ProductsPage.AllProductPage;
import com.myorrg.parenttest.Base;

public class AddReviewOnProduct extends Base {

	WebDriver driver;
	HomePage homePageObj;
	AllProductPage allProductPageObj;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		allProductPageObj = new AllProductPage(driver);

	}@Test(priority = 1, dataProvider = "feeder")
	@Source("\\reviewProductsFile\\ReviewProductsFile.csv")
	public void homePage(String homeHeaderText, String reviewText, String reviewName, String reviewEmail,
			String reviewAddReview) {

	
		String getHeaderText = homePageObj.getHeaderText();
		System.out.println("getHeaderText : " + getHeaderText);
		assertEquals(getHeaderText, homeHeaderText);
		
		allProductPageObj.clickproduct();
		allProductPageObj.ViewProduct();

		String getReviewText = allProductPageObj.getReviewText();
		System.out.println("getReviewText : " + getReviewText);
		assertEquals(getReviewText, reviewText);

		allProductPageObj.reviewDetails(reviewName, reviewEmail, reviewAddReview);

	}
}
