package registerBeforeCheckout;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myoor.AutomationTestCasesPage.MainTestCasesPage;
import com.myoor.PlaceOrderPage.PlaceOrderPage;
import com.myorrg.AddProduct.AddProductPage;
import com.myorrg.AutomationPage.AccountCreationPage;
import com.myorrg.AutomationPage.HomePage;
import com.myorrg.AutomationPage.LoggedPage;
import com.myorrg.AutomationPage.LoginPage;
import com.myorrg.parenttest.Base;

public class RegisterBeforeCheckOutTest extends Base {
	WebDriver driver;
	HomePage homePageObj;
	MainTestCasesPage mainTestCasesPageObj;
	AddProductPage addProductPageObj;
	PlaceOrderPage placeOrderPageObj;
	LoginPage loginPageObj;
	AccountCreationPage accountCreationPageObj;
	LoggedPage loggedPageObj;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		mainTestCasesPageObj = new MainTestCasesPage(driver);
		addProductPageObj = new AddProductPage(driver);
		placeOrderPageObj = new PlaceOrderPage(driver);
		loginPageObj = new LoginPage(driver);
		accountCreationPageObj = new AccountCreationPage(driver);
		loggedPageObj = new LoggedPage(driver);
	}
	
	@Test(priority = 1, dataProvider = "feeder")
	@Source("\\RegisterBeforeCheckOutFiles\\RegisterBeforeCheckOut.csv")
	public void homePage(String homeHeaderText, String name, String emailid, String accountInfoHeaderText, String password, String firstName, String lastName, String company, String address1, String address2, String state,
			String city, String zipCode, String mobileNumber, String accCreatedHeaderText, String loggedHeaderText, String deliveryAddress, String sendDescription, String nameOnCard, String cardNumber, String cvvNumber, String expiryMonth, String expiryYear, String successText) {
		String getHeaderText = homePageObj.getHeaderText();
		System.out.println("getHeaderText : " + getHeaderText);
		assertEquals(getHeaderText, homeHeaderText);
		homePageObj.clickLoginBtn();
		
		loginPageObj.signUpUser(name, emailid);	
		
		String accountInfoText = loginPageObj.accountInfoHeader();
		System.out.println("CreatedPage : " + accountInfoText);
		
		assertEquals(accountInfoText, accountInfoHeaderText, "Actual and Excepted are same");
		
		accountCreationPageObj.fillAccountDetails(password, firstName, lastName, company, address1, address2, state,
				city, zipCode, mobileNumber);
		
		accountCreationPageObj.clickCreateAccountBtn();
		
		String accountCreationHeaderText = accountCreationPageObj.accountCreationHeader();
		System.out.println("accountCreationHeaderText : " + accountCreationHeaderText);
		assertEquals(accountCreationHeaderText, accCreatedHeaderText, "Actual and Excepted are same");
		loggedPageObj.verifyContinue();

		String getloggedHeaderText = loggedPageObj.getLoggedText();
		System.out.println("getloggedHeaderText : " + getloggedHeaderText);
		assertEquals(getloggedHeaderText, loggedHeaderText, "Actual and Excepted are same");
		
		placeOrderPageObj.clickaddCart();
		addProductPageObj.clickViewCart();
		placeOrderPageObj.checkOut();
		
		String getDeliveryAddressText = placeOrderPageObj.getDeliveryAddress();
		System.out.println("getDeliveryAddressText : " + getDeliveryAddressText);
		assertEquals(getDeliveryAddressText, deliveryAddress, "Actual and Excepted are same");
		placeOrderPageObj.sendDescription(sendDescription);
		placeOrderPageObj.paymentDetails(nameOnCard,cardNumber,cvvNumber,expiryMonth,expiryYear);
		String getSuccessTextText = placeOrderPageObj.getSuccessText();
		System.out.println("getSuccessTextText : " + getSuccessTextText);
		assertEquals(getSuccessTextText, successText, "Actual and Excepted are same");
	}
}