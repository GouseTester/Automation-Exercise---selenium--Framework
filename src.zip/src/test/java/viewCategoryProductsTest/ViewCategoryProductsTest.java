package viewCategoryProductsTest;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myoor.AutomationTestCasesPage.MainTestCasesPage;
import com.myorrg.AutomationPage.HomePage;
import com.myorrg.ViewCategoryPage.ViewCategoryPage;
import com.myorrg.parenttest.Base;

public class ViewCategoryProductsTest extends Base {
	WebDriver driver;
	HomePage homePageObj;
	MainTestCasesPage mainTestCasesPageObj;
	ViewCategoryPage viewCategoryPageObj;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		mainTestCasesPageObj = new MainTestCasesPage(driver);
		viewCategoryPageObj = new ViewCategoryPage(driver);
	}

	@Test(priority = 1, dataProvider = "feeder")
	@Source("\\viewCategoryFile\\ViewCategoryFile.csv")
	public void homePage(String homeHeaderText, String categoryText, String womenCategoryText, String menCategoryText) {
		String getHeaderText = homePageObj.getHeaderText();
		System.out.println("getHeaderText : " + getHeaderText);
		assertEquals(getHeaderText, homeHeaderText);

		mainTestCasesPageObj.clickHome();

		String getCategoryText = viewCategoryPageObj.getCategoryText();
		System.out.println("getCategoryText : " + getCategoryText);
		assertEquals(getCategoryText, categoryText);

		String getWomenCategoryText = viewCategoryPageObj.getWomenCategoryText();
		System.out.println("getWomenCategoryText : " + getWomenCategoryText);
		assertEquals(getWomenCategoryText, womenCategoryText);

		viewCategoryPageObj.clickMen();

		String getMenCategoryText = viewCategoryPageObj.getMenCategoryText();
		System.out.println("getMenCategoryText : " + getMenCategoryText);
		assertEquals(getMenCategoryText, menCategoryText);

	}

}
