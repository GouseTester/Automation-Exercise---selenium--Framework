package viewCartBrandTest;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.myorrg.AutomationPage.HomePage;
import com.myorrg.ProductsPage.AllProductPage;
import com.myorrg.ViewCartBrandPage.ViewCartBrandPage;
import com.myorrg.parenttest.Base;

public class ViewCartBrandTest extends Base {
	WebDriver driver;
	HomePage homePageObj;
	AllProductPage allProductPageObj;
	ViewCartBrandPage viewCartBrandPageObj;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		allProductPageObj = new AllProductPage(driver);
		viewCartBrandPageObj = new ViewCartBrandPage(driver);
	}

	@Test(priority = 1, dataProvider = "feeder")
	@Source("\\viewCartBrandFile\\ViewCartBrandFile.csv")
	public void homePage(String homeHeaderText, String brand, String brandCategoryText, String brandCategoryText1) {
		String getHeaderText = homePageObj.getHeaderText();
		System.out.println("getHeaderText : " + getHeaderText);
		assertEquals(getHeaderText, homeHeaderText);

		allProductPageObj.clickproduct();

		String getBrandText = viewCartBrandPageObj.getBrandText();
		System.out.println("getBrandText : " + getBrandText);
		assertEquals(getBrandText, brand);
		viewCartBrandPageObj.clickPolo();

		String getBrandCategoryText = viewCartBrandPageObj.getBrandCategoryText();
		System.out.println("getBrandCategoryText : " + getBrandCategoryText);
		assertEquals(getBrandCategoryText, brandCategoryText);

		viewCartBrandPageObj.clickHAndM();

		String getBrandCategoryText1 = viewCartBrandPageObj.getBrandCategoryText1();
		System.out.println("getBrandCategoryText1 : " + getBrandCategoryText1);
		assertEquals(getBrandCategoryText1, brandCategoryText1);

	}
}
