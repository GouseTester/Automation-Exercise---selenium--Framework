package loginBeforeCheckOutPageTest;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myoor.AutomationTestCasesPage.MainTestCasesPage;
import com.myoor.PlaceOrderPage.PlaceOrderPage;
import com.myorrg.AddProduct.AddProductPage;
import com.myorrg.AutomationPage.AccountCreationPage;
import com.myorrg.AutomationPage.HomePage;
import com.myorrg.AutomationPage.LoggedPage;
import com.myorrg.AutomationPage.LoginPage;
import com.myorrg.UserPage.AutomationLoginPage;
import com.myorrg.parenttest.Base;

public class LoginBeforeCheckOutTest extends Base {
	WebDriver driver;
	HomePage homePageObj;
	AutomationLoginPage automationLoginPageObj;
	MainTestCasesPage mainTestCasesPageObj;
	AddProductPage addProductPageObj;
	PlaceOrderPage placeOrderPageObj;
	LoginPage loginPageObj;
	AccountCreationPage accountCreationPageObj;
	LoggedPage loggedPageObj;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		automationLoginPageObj = new AutomationLoginPage(driver);
		mainTestCasesPageObj = new MainTestCasesPage(driver);
		addProductPageObj = new AddProductPage(driver);
		placeOrderPageObj = new PlaceOrderPage(driver);
		loginPageObj = new LoginPage(driver);
		accountCreationPageObj = new AccountCreationPage(driver);
		loggedPageObj = new LoggedPage(driver);
	}

	@Test(priority = 1, dataProvider = "feeder")
	@Source("loginBeforeCheckOutFile\\LoginBeforeCheckOutFile.csv")
	public void homePage(String homeHeaderText, String loginHedaerText, String emailid, String password,
			String loginAfterText, String deliveryAddress, String sendDescription, String nameOnCard, String cardNumber,
			String cvvNumber, String expiryMonth, String expiryYear, String successText) {
		String getHeaderText = homePageObj.getHeaderText();
		System.out.println("getHeaderText : " + getHeaderText);
		assertEquals(getHeaderText, homeHeaderText);

		homePageObj.clickLoginBtn();
		String loginHeaderText = automationLoginPageObj.loginHeaderText();
		System.out.println("UserPage is : " + loginHeaderText);
		assertEquals(loginHeaderText, loginHedaerText, "Actual and Excepted are same");
		automationLoginPageObj.signUp(emailid, password);

		String getloggedHeaderText = loggedPageObj.getLoggedText();
		System.out.println("getloggedHeaderText : " + getloggedHeaderText);
		assertEquals(getloggedHeaderText, loginAfterText, "Actual and Excepted are same");

		placeOrderPageObj.clickaddCart();
		addProductPageObj.clickViewCart();
		placeOrderPageObj.checkOut();

		String getDeliveryAddressText = placeOrderPageObj.getDeliveryAddress();
		System.out.println("getDeliveryAddressText : " + getDeliveryAddressText);
		assertEquals(getDeliveryAddressText, deliveryAddress, "Actual and Excepted are same");
		placeOrderPageObj.sendDescription(sendDescription);
		placeOrderPageObj.paymentDetails(nameOnCard, cardNumber, cvvNumber, expiryMonth, expiryYear);
		String getSuccessTextText = placeOrderPageObj.getSuccessText();
		System.out.println("getSuccessTextText : " + getSuccessTextText);
		assertEquals(getSuccessTextText, successText, "Actual and Excepted are same");

	}

}
