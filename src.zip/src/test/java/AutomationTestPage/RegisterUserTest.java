package AutomationTestPage;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myorrg.AutomatioExercise.AutomationTestPage;
import com.myorrg.parenttest.Base;

public class RegisterUserTest extends Base {
	WebDriver driver;
	AutomationTestPage automationTestPage;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		automationTestPage = new AutomationTestPage(driver);
	}

	@Test(priority = 1)
	public void HomePage() {
		String text = automationTestPage.VerifyHomePage();
		System.out.println("text is : " + text);

	}

	@Test(priority = 2)
	public void LoginPage() {
		automationTestPage.verifyLoginbtn();

	}

	@Test(priority = 3)
	public void NewUserPage() {
		String UserPage = automationTestPage.VerifyNewUser();
		System.out.println("UserPage is : " + UserPage);
	}

	@Test(priority = 4)
	public void NamePage() {
		automationTestPage.verifyName();

	}

	@Test(priority = 5)
	public void EmailPage() {
		automationTestPage.verifyEmail();

	}

	@Test(priority = 6)
	public void SignupPage() {
		automationTestPage.verifySignup();

	}

	@Test(priority = 7)
	public void information() {
		String CreatedPage = automationTestPage.AccvVsible();
		System.out.println("CreatedPage : " + CreatedPage);
	}

	@Test(priority = 8)
	public void Titlepgae() {
		automationTestPage.verifyTitle();
	}

	@Test(priority = 9)
	public void Password() {
		automationTestPage.verifyPassword();
	}

	@Test(priority = 10)
	public void Date() {
		automationTestPage.verifyDate();
	}

	@Test(priority = 11)
	public void Year() {
		automationTestPage.verifyYear();
	}

	@Test(priority = 12)
	public void SignBox() {
		automationTestPage.checkBox();
	}

	@Test(priority = 13)
	public void ReceiveBox() {
		automationTestPage.checkBox1();
	}

	@Test(priority = 14)
	public void FirstName() {
		automationTestPage.VerifyFirstName();
	}

	@Test(priority = 15)
	public void LastName() {
		automationTestPage.VerifyLastName();
	}

	@Test(priority = 16)
	public void Company() {
		automationTestPage.VerifyCompany();
	}

	@Test(priority = 17)
	public void Address() {
		automationTestPage.VerifyAddress1();

	}

	@Test(priority = 18)
	public void Address1() {
		automationTestPage.VerifyAddress2();

	}

	@Test(priority = 19)
	public void State() {
		automationTestPage.VerifyState();
	}

	@Test(priority = 20)
	public void City() {
		automationTestPage.VerifyCity2();
	}

	@Test(priority = 21)
	public void ZipCode() {
		automationTestPage.VerifyZipCode();
	}

	@Test(priority = 22)
	public void Number() {
		automationTestPage.VerifyNumber();
	}

	@Test(priority = 23)
	public void Created() {
		automationTestPage.VerifyCreated();
	}

	@Test(priority = 24)
	public void Successfull() {
		String AccounntDispaly = automationTestPage.CreatedSuccessful();
		System.out.println("AccounntDispaly : " + AccounntDispaly);
	}

	@Test(priority = 25)
	public void ClickContinue() {
		automationTestPage.VerifyContinue();
	}
}