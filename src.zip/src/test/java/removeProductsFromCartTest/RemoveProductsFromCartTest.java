package removeProductsFromCartTest;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myoor.AutomationTestCasesPage.MainTestCasesPage;
import com.myoor.PlaceOrderPage.PlaceOrderPage;
import com.myorrg.AddProduct.AddProductPage;
import com.myorrg.AutomationPage.HomePage;
import com.myorrg.parenttest.Base;

public class RemoveProductsFromCartTest extends Base {

	WebDriver driver;
	HomePage homePageObj;
	MainTestCasesPage mainTestCasesPageObj;
	AddProductPage addProductPageObj;
	// AllProductPage allProductPageObj;
	PlaceOrderPage placeOrderPageObj;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		mainTestCasesPageObj = new MainTestCasesPage(driver);
		addProductPageObj = new AddProductPage(driver);
		placeOrderPageObj = new PlaceOrderPage(driver);
	}

	@Test(priority = 1, dataProvider = "feeder")
	@Source("\\removeProductCartFile\\RemoveProductCartFile.csv")
	public void homePage(String homeHeaderText, String shoppingCartText, String emptyCartText) {
		String getHeaderText = homePageObj.getHeaderText();
		System.out.println("getHeaderText : " + getHeaderText);
		assertEquals(getHeaderText, homeHeaderText);

		mainTestCasesPageObj.clickHome();
		placeOrderPageObj.clickaddCart();
		addProductPageObj.clickViewCart();

		String getshopCartText = addProductPageObj.getShoppingCartText();
		System.out.println("getshopCartText : " + getshopCartText);
		assertEquals(getshopCartText, shoppingCartText);

		addProductPageObj.clickItemRemove();

		String getemptyCartText = addProductPageObj.getEmptyCartTexts();
		System.out.println("getEmptyCartText : " + getemptyCartText);
		assertEquals(getemptyCartText, emptyCartText);

	}

}
