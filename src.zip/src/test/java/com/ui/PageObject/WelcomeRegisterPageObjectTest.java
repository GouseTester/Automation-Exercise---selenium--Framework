package com.ui.PageObject;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ui.pageobject.RegisterPageObject;
import com.ui.pageobject.WelcomePageObject;

public class WelcomeRegisterPageObjectTest {

	WebDriver driver;
	WelcomePageObject WelcomePageObjectobj;
	RegisterPageObject RegisterPageObjectobj;

	@BeforeTest
	public void initilization() {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.get("https://www.tutorialspoint.com/selenium/practice/login.php");
	}

	@Test(priority = 1)
	public void getHeading() {
		WelcomePageObject WelcomePageObjectobj = new WelcomePageObject(driver);
		String WelcomeHeadText = WelcomePageObjectobj.verifyHeading();
		System.out.println("WelcomeHeadText : " + WelcomeHeadText);

		assertEquals("Welcome, Login In", WelcomeHeadText);
	}

	@Test(priority = 2)
	public void getusername() {
		WelcomePageObject WelcomePageObjectobj = new WelcomePageObject(driver);

		String WelcomeUserNmae = WelcomePageObjectobj.verifyUserName();
		System.out.println("WelcomeUserNmae :" + WelcomeUserNmae);
		assertEquals("", WelcomeUserNmae);
	}

	@Test(priority = 3)
	public void getPassword() {
		WelcomePageObject WelcomePageObjectobj = new WelcomePageObject(driver);

		String WelcomePassword = WelcomePageObjectobj.verifyPassword();
		System.out.println("WelcomePassword : " + WelcomePassword);
		assertEquals("", WelcomePassword);
	}

	@Test(priority = 4)
	public void ClickNewUser() {
		WelcomePageObject WelcomePageObjectobj = new WelcomePageObject(driver);
		WelcomePageObjectobj.ClickNewUser();

	}

	@Test(priority = 5)
	public void getRegisterHeading() {
		RegisterPageObject RegisterPageObjectobj = new RegisterPageObject(driver);

		String RegisterHeading = RegisterPageObjectobj.verifyRegisterPage();
		System.out.println("RegisterHeading  " + RegisterHeading);
		assertEquals("Welcome,Register", RegisterHeading);
	}

	@Test(priority = 6)
	public void getFirstName() {
		RegisterPageObject RegisterPageObjectobj = new RegisterPageObject(driver);
		String firstName = RegisterPageObjectobj.Firstname();
		System.out.println("firstName i s: " + firstName);
		assertEquals("", firstName);
	}

	@Test(priority = 7)
	public void getLastName() {
		RegisterPageObject RegisterPageObjectobj = new RegisterPageObject(driver);
		String Lastname = RegisterPageObjectobj.Lastname();
		System.out.println("Lastname is : " + Lastname);
		assertEquals("", Lastname);
	}

	@Test(priority = 8)
	public void getUserName() {
		RegisterPageObject RegisterPageObjectobj = new RegisterPageObject(driver);
		String UserName = RegisterPageObjectobj.UserName();
		System.out.println("UserName : " + UserName);
		assertEquals("", UserName);
	}

	@Test(priority = 9)
	public void getPassWord() {
		RegisterPageObject RegisterPageObjectobj = new RegisterPageObject(driver);
		String password = RegisterPageObjectobj.password();
		System.out.println("password : " + password);
		assertEquals("", password);
	}

	@AfterTest
	public void Teardown() {
		driver.quit();
	}
}