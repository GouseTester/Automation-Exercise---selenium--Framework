package com.ui.PageFactory;

import static org.testng.Assert.assertEquals;


import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myorrg.parenttest.Base;

public class WelcomeRegisterPageWithCsv extends Base {

	WebDriver driver;
	PageFactoryWelcome pageFactoryWelcomeobj;
	PageFactoryRegister pageFactoryRegisterobj;

	@BeforeTest

	public void setUp() {
		driver = getdriver();
		pageFactoryWelcomeobj = new PageFactoryWelcome(driver);
	    pageFactoryRegisterobj = new PageFactoryRegister(driver);
		System.out.println("@BeforeTest initialization");

	}

	@Test(priority = 1, dataProvider = "feeder")
	@Source("\\DataFiles\\welcomepage.csv")

	public void welcomePageHeading(String tcId, String description, String exceptedValue) {
		System.out.println("TcId : " + tcId);
		System.out.println("Description : " + description);
		System.out.println("ExceptedValue : " + exceptedValue);
		String headingText = pageFactoryWelcomeobj.verifyPageHeading();
		System.out.println(headingText);
		assertEquals(headingText, exceptedValue, "Actual and Excepted are same");

	}
	

	@Test(priority = 2, dataProvider = "feeder")
	@Source("\\DataFiles\\RegisterPage.csv")
	public void registerPageHeading(String tcId, String description, String exceptedValue) {
		System.out.println("TcId : " + tcId);
		System.out.println("Description : " + description);
		System.out.println("ExceptedValue : " + exceptedValue);
		pageFactoryWelcomeobj.clickNewUser();
		String headingText = pageFactoryRegisterobj.verifyRegisterPage();
		System.out.println(headingText);
		assertEquals(headingText, exceptedValue);
	}

//		@Test(priority = 2)
//		public void username() {
//			PageFactoryWelcomeobj = new PageFactoryWelcome(driver);
//			String userText = PageFactoryWelcomeobj.verifyUserName();
//			System.out.println(userText);
//			assertEquals("", userText);
//		}
//
//		@Test(priority = 3)
//		public void password() {
//			PageFactoryWelcomeobj = new PageFactoryWelcome(driver);
//			String passwordText = PageFactoryWelcomeobj.verifyPassword();
//			System.out.println(passwordText);
//			assertEquals("", passwordText);
//		}
//
//		@Test(priority = 4)
//		public void newUser() {
//			PageFactoryWelcomeobj = new PageFactoryWelcome(driver);
//			PageFactoryWelcomeobj.clickNewUser();
//
//		}
//
//		@Test(priority = 5)
//		public void registerPageHeading() {
//			PageFactoryRegisterobj = new PageFactoryRegister(driver);
//			String headingText = PageFactoryRegisterobj.verifyRegisterPage();
//			System.out.println(headingText);
//			assertEquals("Welcome,Register", headingText);
//		}
//
//		@Test(priority = 6)
//		public void firstName() {
//			PageFactoryRegisterobj = new PageFactoryRegister(driver);
//			String firstName = PageFactoryRegisterobj.verifyFirstName();
//			System.out.println(firstName);
//			assertEquals("", firstName);
//		}
//
//		@Test(priority = 7)
//		public void lastName() {
//			PageFactoryRegisterobj = new PageFactoryRegister(driver);
//			String lastName = PageFactoryRegisterobj.verifyLastName();
//			System.out.println(lastName);
//			assertEquals("", lastName);
//
//		}
//
//		@Test(priority = 8)
//		public void userName() {
//			PageFactoryRegisterobj = new PageFactoryRegister(driver);
//			String userName = PageFactoryRegisterobj.verifyUserName();
//			System.out.println(userName);
//			assertEquals("", userName);
//		}
//
//		@Test(priority = 9)
//		public void passwordText() {
//			PageFactoryRegisterobj = new PageFactoryRegister(driver);
//			String passwordText = PageFactoryRegisterobj.verifyPassword();
//			System.out.println(passwordText);
//			assertEquals("", passwordText);
//
//		}
//
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
