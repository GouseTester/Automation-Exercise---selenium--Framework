package com.myorrg.AddCartTest;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myoor.AutomationTestCasesPage.MainTestCasesPage;
import com.myorrg.AddProduct.AddProductPage;
import com.myorrg.AutomationPage.HomePage;
import com.myorrg.ProductsPage.AllProductPage;
import com.myorrg.ProductsPage.ViewProductPage;
import com.myorrg.parenttest.Base;

public class AddProductPageTest extends Base {
	WebDriver driver;
	HomePage homePageObj;
	AllProductPage allProductPageObj;
	AddProductPage addProductPageObj;
	MainTestCasesPage mainTestCasesPageObj;
	ViewProductPage viewProductPageObj;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		allProductPageObj = new AllProductPage(driver);
		addProductPageObj = new AddProductPage(driver);
		mainTestCasesPageObj = new MainTestCasesPage(driver);
		allProductPageObj = new AllProductPage(driver);
		viewProductPageObj = new ViewProductPage(driver);
	}

	@Test(priority = 1, dataProvider = "feeder")
	@Source("\\AddProductFile\\AddProducts.csv")
	public void homePage(String homeHeaderText, String priceText, String priceText1, String quantityText,
			String quantityText1, String nameText, String quantityIncreaseText1) {
		String getHeaderText = homePageObj.getHeaderText();
		System.out.println("getHeaderText : " + getHeaderText);
		assertEquals(getHeaderText, homeHeaderText);
		allProductPageObj.clickproduct();

		addProductPageObj.clickAddCart();
		String getPriceText = addProductPageObj.priceText();
		System.out.println("getPriceText : " + getPriceText);
		assertEquals(getPriceText, priceText);

		String getPriceText1 = addProductPageObj.priceText1();
		System.out.println("getPriceText1 : " + getPriceText1);
		assertEquals(getPriceText1, priceText1);

		String getQuantityText = addProductPageObj.quantityText();
		System.out.println("getQuantityText : " + getQuantityText);
		assertEquals(getQuantityText, quantityText);

		String getQuantityText1 = addProductPageObj.quantityText1();
		System.out.println("getQuantityText1 : " + getQuantityText1);
		assertEquals(getQuantityText1, quantityText1);
		mainTestCasesPageObj.clickHome();

		allProductPageObj.ViewProduct();
		String getnameText = viewProductPageObj.nameDetails();
		System.out.println("getnameText : " + getnameText);
		assertEquals(getnameText, nameText);

		addProductPageObj.addCart();

		addProductPageObj.clickViewCart();

		String getIncreaseQuantityText = addProductPageObj.quantityIncreaseElement();
		System.out.println("getIncreaseQuantityText : " + getIncreaseQuantityText);
		assertEquals(getIncreaseQuantityText, quantityIncreaseText1);

	}
}
