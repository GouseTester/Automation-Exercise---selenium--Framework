package com.myorrg.AutomationUserTest;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myorrg.AutomationPage.HomePage;
import com.myorrg.UserPage.AutomationDeletePage;
import com.myorrg.UserPage.AutomationLoginPage;
import com.myorrg.parenttest.Base;

public class UserPageTest extends Base {
	WebDriver driver;
	HomePage homePageObj;
	//AutomationhomePage automationhomePageObj;

	AutomationLoginPage automationLoginPageObj;
	AutomationDeletePage automationDeletePageObj;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		//automationhomePageObj = new AutomationhomePage(driver);
		automationLoginPageObj = new AutomationLoginPage(driver);
		automationDeletePageObj = new AutomationDeletePage(driver);
	}

	@Test(priority = 1, dataProvider = "feeder")
	@Source("\\UserCredentials\\HomePage.csv")
	public void homePage(String id, String description, String exceptedValue) {
		System.out.println("id is : " + id);
		System.out.println("description is : " + description);
		System.out.println("exceptedValue is : " + exceptedValue);
		String headerText = homePageObj.getHeaderText();
		System.out.println("text is : " + headerText);
		assertEquals(headerText, exceptedValue, "Actual and Excepted are same");
	}

	@Test(priority = 2, dataProvider = "feeder")
	@Source("\\UserCredentials\\LoginUser.csv")
	public void loginPage(String id, String description, String exceptedValue) {
		System.out.println("id is : " + id);
		System.out.println("description is : " + description);
		System.out.println("exceptedValue is : " + exceptedValue);
		homePageObj.clickLoginBtn();
		String loginHeaderText = automationLoginPageObj.loginHeaderText();
		System.out.println("UserPage is : " + loginHeaderText);
		assertEquals(loginHeaderText, exceptedValue, "Actual and Excepted are same");

	}

	@Test(priority = 3, dataProvider = "feeder")
	@Source("\\UserCredentials\\LoggedPage.csv")
	public void loggedPage(String email, String password, String exceptedValue) {
		System.out.println("email is : " + email);
		System.out.println("password is : " + password);
		automationLoginPageObj.signUp(email, password);

		String loggedHeaderText = automationDeletePageObj.loginUserHeaderText();
		System.out.println("loggedHeaderText : " + loggedHeaderText);
		assertEquals(loggedHeaderText, exceptedValue, "Actual and Excepted are same");

	}

	@Test(priority = 4, dataProvider = "feeder")
	@Source("\\UserCredentials\\LogoutPage.csv")
	public void deletePage(String tcId, String tcDescription, String exceptedValue) {
		automationDeletePageObj.deleteAccount();
		String ActualHeletedHeaderText = automationDeletePageObj.deletedHeaderText();
		System.out.println("deletedHeaderText : " + ActualHeletedHeaderText);
		assertEquals(ActualHeletedHeaderText, exceptedValue, "Actual and Excepted are same");

	}

}
