package com.myorrg.AutomationTestcasesTest;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myoor.AutomationTestCasesPage.MainTestCasesPage;
import com.myorrg.AutomationPage.HomePage;
import com.myorrg.parenttest.Base;

public class TestCasesPageTest extends Base {
	WebDriver driver;
	HomePage homePageObj;
	MainTestCasesPage mainTestCasesPageObj;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		mainTestCasesPageObj = new MainTestCasesPage(driver);
	}

	@Test(priority = 1, dataProvider = "feeder")
	@Source("\\TestCasesData\\TestCasesFile.csv")
	public void homePage(String homeHeaderText, String homeHeaderText1) {
		String headerText = homePageObj.getHeaderText();
		System.out.println("headerText : " + headerText);
		assertEquals(headerText, homeHeaderText, " Actual and Excepted are Same");

		mainTestCasesPageObj.clickHome();
		mainTestCasesPageObj.clickTestCases();
		String actualHeaderText = mainTestCasesPageObj.getTestCaseHeader();
		System.out.println("headerText : " + actualHeaderText);
		assertEquals(actualHeaderText, homeHeaderText1, " Actual and Excepted are Same");

	}
}

//	@Test(priority = 2, dataProvider = "feeder")
//	@Source("\\TestCasesData\\MainTestCase.csv")
//
//	public void testCasePage(String tcId, String tcDescription, String exceptedValue) {
// testCasesPageObj.clickTestCases();
//		mainTestCasesPageObj.clickHome();
//		mainTestCasesPageObj.clickTestCases();
//		String actualHeaderText = mainTestCasesPageObj.getTestCaseHeader();
//		System.out.println("headerText : " + actualHeaderText);
//		assertEquals(actualHeaderText, exceptedValue, " Actual and Excepted are Same");
