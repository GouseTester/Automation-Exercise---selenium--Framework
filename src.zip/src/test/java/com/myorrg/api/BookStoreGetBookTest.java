package com.myorrg.api;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BookStoreGetBookTest {
	@Test
	public void getBook() {
		RestAssured.baseURI = "https://demoqa.com/BookStore/v1/Book";
	RequestSpecification httpRequest = RestAssured.given();
	Response response = httpRequest.queryParam("ISBN", "9781449325862").request(Method.GET);
	
	String ResponseData = response.asPrettyString();
	System.out.println("ResponseData : "+ ResponseData);
	System.out.println("Status received : "+ response.getStatusCode());
	 int actualCode = response.getStatusCode();
	 int excepetedcode = 200;
	 
	 Assert.assertEquals(actualCode, excepetedcode);

	
	
	
	}

}
