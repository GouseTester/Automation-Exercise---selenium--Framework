package com.myorrg.api;


import org.databene.benerator.anno.Source;
import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.myorrg.parenttest.Base;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class JsonObjectAndArrayTest extends Base{
	@Test(dataProvider = "feeder")
	@Source("\\JsonObjectArrayFile\\JsonArrayFile.csv")
	public void Details(String Book) {
		RestAssured.baseURI = "https://demoqa.com/BookStore/v1/Books";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		
		String ResponseData = response.asPrettyString();
		System.out.println("ResponseData : "+ResponseData);
		
		Gson gson = new Gson();
		JsonObject jsonObject = gson.fromJson(ResponseData, JsonObject.class);
		System.out.println("jsonObject : "+ jsonObject);
		System.out.println("jsonObject : "+ jsonObject.get("books"));

		JsonArray jsonArray = gson.fromJson(jsonObject.get("books"), JsonArray.class);
		System.out.println("jsonArray : "+jsonArray);
		for(int i=0; i<jsonArray.size(); i++) {
			JsonObject jsonObject1 = jsonArray.get(i).getAsJsonObject();
			System.out.println(i+ ":" + jsonObject1);
		}
	}
	
	
	
	
//@Test
//	public void Details() {
//		RestAssured.baseURI = "https://demoqa.com/BookStore/v1/Books";
//	    RequestSpecification httpRequest = RestAssured.given();
//	    Response response = httpRequest.request(Method.GET);
//		 String responseData = response.asPrettyString();
//		 System.out.println("responseData :"+ responseData);
//		 
//		 Gson gson = new Gson();
//		 JsonObject jsonObject = gson.fromJson(responseData, JsonObject.class);
//System.out.println("jsonObject : "+ jsonObject);
//
//System.out.println("jsonObjectBooks : "+ jsonObject.get("books"));
//System.out.println("jsonObjectIsbn : "+ jsonObject.get("isbn"));
//
//String JsonArrayString = jsonObject.get("books").toString();
//JsonArray jsonArray = gson.fromJson(JsonArrayString, JsonArray.class);
//System.out.println("jsonArray : "+ jsonArray);
//
//for (int i=0; i<jsonArray.size(); i++) {
//	JsonObject  jsonObject1 = jsonArray.get(i).getAsJsonObject();
//	System.out.println(i+ ":" +jsonObject1);
//	System.out.println("isbn :" + jsonObject1.get("isbn"));
//	System.out.println("title :" + jsonObject1.get("title"));
//
//}
//
//}
	
}
