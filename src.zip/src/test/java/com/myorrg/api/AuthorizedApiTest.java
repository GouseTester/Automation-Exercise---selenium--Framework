package com.myorrg.api;

import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

public class AuthorizedApiTest {

	@Test
	public void generateToken() {
		// Set the base URL (root domain)
		RestAssured.baseURI = "https://demoqa.com";

		String requestBody = """
				{
				  "userName": "Gouse81@",
				  "password": "Gouse81@"
				}
				""";

		Response response = given()
				.header("Content-Type", "application/json")
				.body(requestBody)
				.post("/Account/v1/Authorized");
		System.out.println(response.statusCode());
		int exceptedStatusCode = 200;
		int actualStatusCode = response.getStatusCode();
		Assert.assertEquals(exceptedStatusCode, actualStatusCode, "Both are Same");

		String exceptedValue = "true";
		String actualValue = response.prettyPrint();
		Assert.assertEquals(exceptedValue, actualValue, "Bot are same");

	}
}
