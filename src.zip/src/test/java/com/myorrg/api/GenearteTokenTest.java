package com.myorrg.api;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GenearteTokenTest {
	@Test
	public void generateToken() {
		RestAssured.baseURI = "https://demoqa.com/Account/v1/GenerateToken";

		String requestBody = """
				{
				"userName" : "Gouse81@",
				"password" : "Gouse81@"

				}

				""";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);

		System.out.println(response.statusCode());
		int actualStatusCode = 200;
		int exceptedStatusCode = response.getStatusCode();
		Assert.assertEquals(actualStatusCode, exceptedStatusCode);
		System.out.println(response.getStatusLine());

		System.out.println(response.prettyPrint());

	}
}
