package com.myorrg.api;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UserUUIDTest {
@Test
	public void userUuid() {
		RestAssured.baseURI = "https://demoqa.com/Account/v1/User";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		System.out.println("response : " + response.statusCode());
		System.out.println("response : " + response.prettyPrint());

	}
}