package com.myorrg.IncorrectCredentials;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myorrg.AutomationPage.HomePage;
import com.myorrg.WrongUserCredentials.WrongCredentialsLoginPage;
import com.myorrg.parenttest.Base;

public class WrongCredentialPageTest extends Base {
	WebDriver driver;
	HomePage homePageObj;
	//WrongCredentialshomePage wrongCredentialsHomePageObj;
	WrongCredentialsLoginPage wrongCredentialsLoginPageObj;
	
	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		//wrongCredentialsHomePageObj = new WrongCredentialshomePage(driver);
		wrongCredentialsLoginPageObj = new WrongCredentialsLoginPage(driver);
	}

	@Test(priority = 1, dataProvider = "feeder")
	@Source("\\WrongUserCredentials\\HomePage.csv")
	public void homePage(String id, String description, String exceptedValue) {
		System.out.println("id is : " + id);
		System.out.println("description is : " + description);
		System.out.println("exceptedValue is : " + exceptedValue);
		String actual = homePageObj.getHeaderText();
		System.out.println("Actual is : " + actual);
		assertEquals(actual, exceptedValue, "Actual and Excepted are same");
	}

	@Test(priority = 2, dataProvider = "feeder")
	@Source("\\WrongUserCredentials\\LoggedPage.csv")
	public void loginPage(String tcId, String tcDescription, String exceptedValue) {
		System.out.println("tcId is : " + tcId);
		System.out.println("description is : " + tcDescription);
		System.out.println("exceptedValue is : " + exceptedValue);
		homePageObj.clickLoginBtn();
		String actual = wrongCredentialsLoginPageObj.loginHeaderText();
		System.out.println("Actual is : " + actual);
		assertEquals(actual, exceptedValue, "Actual and Excepted are same");

	}

	@Test(priority = 3, dataProvider = "feeder")
	@Source("\\WrongUserCredentials\\LoginUser.csv")
	public void loggedPage(String email, String password, String exceptedValue) {
		System.out.println("email is : " + email);
		System.out.println("password is : " + password);
		
		wrongCredentialsLoginPageObj.loginUserCredentials(email, password);
		String wrongDetail = wrongCredentialsLoginPageObj.wrongDetailsHeaderText();
		System.out.println("wrongDetails : " + wrongDetail);
		assertEquals(wrongDetail, exceptedValue, "Actual and Excepted are same");
	}
}
