package recommendedProductsTest;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myoor.AutomationTestCasesPage.MainTestCasesPage;
import com.myorrg.AutomationPage.HomePage;
import com.myorrg.SubscriptionPage.SubscriptionHomePage;
import com.myorrg.parenttest.Base;

public class RecommendedProductsTest extends Base {

	WebDriver driver;
	HomePage homePageObj;
	MainTestCasesPage mainTestCasesPageObj;
	SubscriptionHomePage subscriptionHomePageObj;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		mainTestCasesPageObj = new MainTestCasesPage(driver);
		subscriptionHomePageObj = new SubscriptionHomePage(driver);
	}

	@Test(priority = 1, dataProvider = "feeder")
	@Source("\\recommendedFile\\RecommendedFile.csv")
	public void homePage(String homeHeaderText, String recommendedProductText, String recommendeCartText) {
		String getHeaderText = homePageObj.getHeaderText();
		System.out.println("getHeaderText : " + getHeaderText);
		assertEquals(getHeaderText, homeHeaderText);
		mainTestCasesPageObj.clickHome();
		subscriptionHomePageObj.scrollToRecommended();
		
		String getRecommendedText = subscriptionHomePageObj.getRecommendedProductsText();
		System.out.println("getRecommendedText : " + getRecommendedText);
		assertEquals(getRecommendedText, recommendedProductText);
		
		subscriptionHomePageObj.clickRecommendedCartView();
		
		String getRecommendeCartText = subscriptionHomePageObj.getRecommendedCartText();
				System.out.println("getRecommendeCartText : " + getRecommendeCartText);
		assertEquals(getRecommendeCartText, recommendeCartText);
	}
}
