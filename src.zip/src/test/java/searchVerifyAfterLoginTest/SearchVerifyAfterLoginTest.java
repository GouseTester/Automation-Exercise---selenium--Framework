package searchVerifyAfterLoginTest;

import static org.testng.Assert.assertEquals;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myoor.PlaceOrderPage.PlaceOrderPage;
import com.myorrg.AutomationPage.HomePage;
import com.myorrg.ProductsPage.AllProductPage;
import com.myorrg.SearchProductPage.ProductSearchPage;
import com.myorrg.UserPage.AutomationLoginPage;
import com.myorrg.parenttest.Base;

public class SearchVerifyAfterLoginTest extends Base {
	WebDriver driver;
	HomePage homePageObj;
	AllProductPage allProductPageObj;
	ProductSearchPage productSearchPageObj;
	AutomationLoginPage automationLoginPageObj;
	PlaceOrderPage placeOrderPageObj;

	@BeforeTest
	public void initialization() {
		driver = getdriver();
		homePageObj = new HomePage(driver);
		allProductPageObj = new AllProductPage(driver);
		productSearchPageObj = new ProductSearchPage(driver);
		automationLoginPageObj = new AutomationLoginPage(driver);
		placeOrderPageObj = new PlaceOrderPage(driver);
	}

	@Test(priority = 1, dataProvider = "feeder")
	@Source("\\searchVerifyProductFile\\SearchVerifyProductFile.csv")
	public void homePage(String homeHeaderText, String productText, String searchedProductText, String CartProductText, String emailId, String password, String CartProductText1) {
		String getHeaderText = homePageObj.getHeaderText();
		System.out.println("getHeaderText : " + getHeaderText);
		assertEquals(getHeaderText, homeHeaderText);

		allProductPageObj.clickproduct();
		
		String getProductText = allProductPageObj.productPage();
		System.out.println("getProductText : " + getProductText);
		assertEquals(getProductText, productText);
		
		productSearchPageObj.clickSearch();
		
		String getSerachedProductText = productSearchPageObj.searcheTestdPage();
		System.out.println("getCartProductText : " + getSerachedProductText);
		assertEquals(getSerachedProductText, searchedProductText);
		//productSearchPageObj.searcheTestdPage();
		
		productSearchPageObj.clickAddCart();
		
		String getCartProductText = productSearchPageObj.getProductInCartText();
		System.out.println("getCartProductText : " + getCartProductText);
		assertEquals(getCartProductText, CartProductText);
		
		//productSearchPageObj.getProductInCartText();
		
//		productSearchPageObj.clickAddCart();
		homePageObj.clickLoginBtn();
		automationLoginPageObj.signUp(emailId, password);
		
		placeOrderPageObj.clickCart();
		
		String getCartProductText1 = productSearchPageObj.getProductInCartText();
		System.out.println("getCartProductText1 : " + getCartProductText1);
		assertEquals(getCartProductText1, CartProductText1);

		
		
	}

}