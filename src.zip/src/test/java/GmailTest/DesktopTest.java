package GmailTest;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.myorrg.PageObject.Gmail.GmailPage;

public class DesktopTest {
	WebDriver driver;
	GmailPage GmailDesktopobj;

	@BeforeTest
	public void setUp() {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.get("https://accounts.google.com/signin");
	}

//	https://accounts.google.com/signin
//	https://www.google.com/search?q=gmail+login&oq=gmail&gs_lcrp=EgZjaHJvbWUqDwgAEEUYOxiDARixAxiABDIPCAAQRRg7GIMBGLEDGIAEMg8IARBFGDsYgwEYsQMYgAQyCggCEAAYsQMYgAQyCggDEAAYsQMYgAQyBggEEEUYPDIGCAUQRRg8MgYIBhBFGD0yBggHEEUYQdIBCDI4NDNqMGo3qAIIsAIB8QVFJMDKw-erWA&sourceid=chrome&ie=UTF-8&sei=-i6KaJX8FY7lseMP7bWjyQs
//	@Test(priority = 1)
//	public void clickbtn() {
//		GmailPage GmailDesktopobj = new GmailPage(driver);
//		GmailDesktopobj.Click();
//	}
//
//	@Test(priority = 2)
//	public void signbtn() {
//		GmailPage GmailDesktopobj = new GmailPage(driver);
//		GmailDesktopobj.sign();
//	}
	@Test(priority = 3)
	public void Email() {
		GmailPage GmailDesktopobj = new GmailPage(driver);
		GmailDesktopobj.Email();
	}

	@Test(priority = 4)
	public void Next() {
		GmailPage GmailDesktopobj = new GmailPage(driver);
		GmailDesktopobj.Next();

	}
//	@AfterTest
//	public void teardown() {
//		driver.quit();

}

//	}	
//	@Test(priority = 2)
//	public void Email() {
//		GmailDesktop GmailDesktopobj= new GmailDesktop(driver);
//		GmailDesktopobj.Email();
//	}
//	@Test(priority = 3)
//	public void Next() {
//		GmailDesktop GmailDesktopobj= new GmailDesktop(driver);
//		GmailDesktopobj.Next();
//	
//}
