package com.myorrg.UserPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AutomationDeletePage {
	WebDriver driver;
	@FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[10]/a")
	WebElement loginAsVisibleElement;

	@FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[5]/a")
	WebElement clickDeleteElement;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div/h2/b")
	WebElement accountDeletedElement;

	public AutomationDeletePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public String loginUserHeaderText() {
		String loginUserName = loginAsVisibleElement.getText();
		return loginUserName;
	}

	public void deleteAccount() {
		clickDeleteElement.click();

	}

	public String deletedHeaderText() {
		String headerText = accountDeletedElement.getText();
		return headerText;

	}
}
