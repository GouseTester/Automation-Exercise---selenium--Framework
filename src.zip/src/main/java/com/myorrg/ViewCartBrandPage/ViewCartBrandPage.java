package com.myorrg.ViewCartBrandPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ViewCartBrandPage {
	WebDriver driver;

	@FindBy(xpath = "//div[@class=\"brands_products\"]/h2")
	WebElement brandElement;
	@FindBy(xpath = "//ul[@class=\"nav nav-pills nav-stacked\"]/li/a[text()=\"Polo\"]")
	WebElement clickPoloElement;

	@FindBy(xpath = "/html/body/section/div/div[2]/div[2]/div/h2")
	WebElement brandCategoryElement;

	@FindBy(xpath = "/html/body/section/div/div[2]/div[1]/div/div[2]/div/ul/li[2]/a")
	WebElement clickHandMElement;

	@FindBy(xpath = "/html/body/section/div/div[2]/div[2]/div/h2")
	WebElement brandCategoryElement1;

	public ViewCartBrandPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public String getBrandText() {
		String brandText = brandElement.getText();
		return brandText;

	}

	public void clickPolo() {
		clickPoloElement.click();
	}

	public String getBrandCategoryText() {
		String brandCategoryText = brandCategoryElement.getText();
		return brandCategoryText;

	}

	public void clickHAndM() {
		clickHandMElement.click();
	}

	public String getBrandCategoryText1() {
		String brandCategoryText = brandCategoryElement1.getText();
		return brandCategoryText;

	}
}
