package com.myorrg.ViewCategoryPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ViewCategoryPage {
	WebDriver driver;
	@FindBy(xpath = "/html/body/section[2]/div/div/div[1]/div/h2")
	WebElement categoryElement;

	@FindBy(xpath = "//*[@id=\"accordian\"]/div[1]/div[1]/h4/a")
	WebElement clickOnWomenElement;

	@FindBy(xpath = "//*[@id=\"Women\"]/div/ul/li[1]/a")
	WebElement clickOnDressElement;

	
	@FindBy(xpath = "//html/body/section/div/div[2]/div[2]/div/h2")
	WebElement verifyWomenCategoryElement;

	@FindBy(xpath = "//*[@id=\"accordian\"]/div[2]/div[1]/h4/a")
	WebElement clickOnMenElement;

	@FindBy(xpath = "//*[@id=\"Men\"]/div/ul/li[1]/a")
	WebElement clickOnTshirtElement;

	@FindBy(xpath = "/html/body/section/div/div[2]/div[2]/div/h2")
	WebElement verifyMenCategoryElement;

	public ViewCategoryPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public String getCategoryText() {
		String categoryText = categoryElement.getText();
		return categoryText;

	}

	public void clickWomen() {
		clickOnWomenElement.click();
		clickOnDressElement.click();
	}

	public String getWomenCategoryText() {
		String categoryText = verifyWomenCategoryElement.getText();
		return categoryText;

	}

	public void clickMen() {
		clickOnMenElement.click();
		clickOnTshirtElement.click();
	}

	public String getMenCategoryText() {
		String categoryText = verifyMenCategoryElement.getText();
		return categoryText;

	}

}