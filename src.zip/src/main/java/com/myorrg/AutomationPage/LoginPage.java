package com.myorrg.AutomationPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	
	WebDriver driver;
	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div[3]/div/h2")
	WebElement userVisibleElement;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div[3]/div/form/input[2]")
	WebElement nameTextElement;
	
	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div[3]/div/form/input[3]")
	WebElement emailTextElement;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div[3]/div/form/button")
	WebElement signupElement;
	
	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div/div[1]/h2/b")
	WebElement accountVisibleElement;	

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public String newUserSignUpHeader() {
		String NewUser = userVisibleElement.getText();
		return NewUser;
	}

	public void signUpUser(String name, String emailId) {
		nameTextElement.sendKeys(name);
		String emailIdNew = System.currentTimeMillis()+"a@aa.com";
		emailTextElement.sendKeys(emailIdNew);
		signupElement.click();
	}

	public String accountInfoHeader() {
		String account = accountVisibleElement.getText();
		return account;
	
	}
}
