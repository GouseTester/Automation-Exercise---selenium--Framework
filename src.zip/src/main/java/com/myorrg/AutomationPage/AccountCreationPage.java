package com.myorrg.AutomationPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class AccountCreationPage {
	WebDriver driver;
	@FindBy(xpath = "//*[@id=\"id_gender1\"]")
	WebElement titleElemant;

	@FindBy(xpath = "//*[@id=\"password\"]")
	WebElement passwordElement;

	@FindBy(xpath = "//*[@id=\"days\"]")
	WebElement daydropDownElement;

	@FindBy(xpath = "//*[@id=\"months\"]")
	WebElement monthDropDownElement;

	@FindBy(xpath = "//*[@id=\"years\"]")
	WebElement yearDropDownElement;

	@FindBy(xpath = "//*[@id=\"newsletter\"]")
	WebElement signCheckBoxElement;

	@FindBy(xpath = "//*[@id=\"optin\"]")
	WebElement receiveCheckBoxElement;

	@FindBy(xpath = "//*[@id=\"first_name\"]")
	WebElement firstNameElement;

	@FindBy(xpath = "//*[@id=\"last_name\"]")
	WebElement lastNameElement;

	@FindBy(xpath = "//*[@id=\"company\"]")
	WebElement companyElement;

	@FindBy(xpath = "//*[@id=\"address1\"]")
	WebElement address1Element;

	@FindBy(xpath = "//*[@id=\"address2\"]")
	WebElement address2Element;

	@FindBy(xpath = "//*[@id=\"state\"]")
	WebElement stateElement;

	@FindBy(xpath = "//*[@id=\"city\"]")
	WebElement cityElement;

	@FindBy(xpath = "//*[@id=\"zipcode\"]")
	WebElement zipCodeElement;

	@FindBy(xpath = "//*[@id=\"mobile_number\"]")
	WebElement mobileNumberElement;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div/div[1]/form/button")
	WebElement accCreatedElement;
	
	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div/h2/b")
	WebElement createdElement;
	
	public AccountCreationPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void fillAccountDetails(String password, String firstName, String lastName, String company, String address1,
			String address2, String state, String city, String zipCode, String mobileNumber) {
		titleElemant.click();
		passwordElement.sendKeys(password);
		verifyDate();
		verifyMonth();
		verifyYear();
		signCheckBoxElement.click();
		receiveCheckBoxElement.click();
		firstNameElement.sendKeys(firstName);
		lastNameElement.sendKeys(lastName);
		companyElement.sendKeys(company);
		address1Element.sendKeys(address1);
		address2Element.sendKeys(address2);
		stateElement.sendKeys(state);
		cityElement.sendKeys(city);
		zipCodeElement.sendKeys(zipCode);
		mobileNumberElement.sendKeys(mobileNumber);

	}
	
	public void verifyDate() {
		Select daySelect = new Select(daydropDownElement);
		daySelect.selectByValue("17");
	}

	public void verifyMonth() {
		Select monthSelect = new Select(monthDropDownElement);
		//monthSelect.selectByValue("January");
		monthSelect.selectByVisibleText("January");
	}

	public void verifyYear() {
		Select yearSelect = new Select(yearDropDownElement);
		yearSelect.selectByValue("2000");
		//yearSelect.selectByVisibleText("2000");
	}

	public void clickCreateAccountBtn() {
		accCreatedElement.click();
	}
	public String accountCreationHeader() {
		String accounntDisplay = createdElement.getText();
		return accounntDisplay;

}
	
}