package com.myorrg.PageObject.Gmail;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GmailPage {
	WebDriver driver;
	By Email = By.xpath("//*[@id=\"identifierId\"]");
	By Next = By.xpath("//*[@id=\"identifierNext\"]/div/button/span");

	public GmailPage(WebDriver driver) {
		this.driver = driver;
	}

	public void Email() {
		WebElement EmailElement = driver.findElement(Email);
		EmailElement.sendKeys("shaikgousebasha81@gmail.com");
	}

	public void Next() {
		WebElement NextElement = driver.findElement(Next);
		NextElement.click();
	}

}
