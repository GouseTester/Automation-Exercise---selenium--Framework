package com.myorrg.AutomatioExercise;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class AutomationTestPage {

	WebDriver driver;
	@FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[1]/div/a/img")
	WebElement HomeText;

	@FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")
	WebElement Loginbtn;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div[3]/div/h2")
	WebElement UserVisible;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div[3]/div/form/input[2]")
	WebElement NameText;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div[3]/div/form/input[3]")
	WebElement EmailText;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div[3]/div/form/button")
	WebElement Signup;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div/div[1]/h2/b")
	WebElement AccountVisible;

	@FindBy(xpath = "//*[@id=\"id_gender1\"]")
	WebElement Title;

	@FindBy(xpath = "//*[@id=\"password\"]")
	WebElement Password;

	@FindBy(xpath = "//*[@id=\"days\"]")
	WebElement DaydropDown;

	@FindBy(xpath = "//*[@id=\"months\"]")
	WebElement MonthDropDown;

	@FindBy(xpath = "//*[@id=\"years\"]")
	WebElement YearDropDown;

	@FindBy(xpath = "//*[@id=\"newsletter\"]")
	WebElement SignCheckBox;

	@FindBy(xpath = "//*[@id=\"optin\"]")
	WebElement ReceiveCheckBox;

	@FindBy(xpath = "//*[@id=\"first_name\"]")
	WebElement FirstName;

	@FindBy(xpath = "//*[@id=\"last_name\"]")
	WebElement LastName;

	@FindBy(xpath = "//*[@id=\"company\"]")
	WebElement Company;

	@FindBy(xpath = "//*[@id=\"address1\"]")
	WebElement Address1;

	@FindBy(xpath = "//*[@id=\"address2\"]")
	WebElement Address2;

	@FindBy(xpath = "//*[@id=\"state\"]")
	WebElement State;

	@FindBy(xpath = "//*[@id=\"city\"]")
	WebElement City;

	@FindBy(xpath = "//*[@id=\"zipcode\"]")
	WebElement ZipCode;

	@FindBy(xpath = "//*[@id=\"mobile_number\"]")
	WebElement Number;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div/div[1]/form/button")
	WebElement AccCreated;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div/h2/b")
	WebElement Created;
	
	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div/div/a")
	WebElement Continue;

	
	public AutomationTestPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public String VerifyHomePage() {
		String HomePage = HomeText.getText();
		return HomePage;
	}

	public void verifyLoginbtn() {
		Loginbtn.click();
	}

	public String VerifyNewUser() {
		String NewUser = UserVisible.getText();
		return NewUser;
	}

	public void verifyName() {
		NameText.sendKeys("Gouse");
	}

	public void verifyEmail() {
		EmailText.sendKeys("gousebhai81@gmail.com");
	}

	public void verifySignup() {
		Signup.click();
	}

	public String AccvVsible() {
		String Account = AccountVisible.getText();;
		return Account;
	}

	public void verifyTitle() {
		Title.click();
	}

	public void verifyPassword() {
		Password.sendKeys("Gouse81@");

	}

	public void verifyDate() {
		Select DaySelect = new Select(DaydropDown);
		DaySelect.selectByValue("17");
	}

	public void verifyMOnth() {
		Select DaySelect = new Select(MonthDropDown);
		DaySelect.selectByValue("January");
	}

	public void verifyYear() {
		Select DaySelect = new Select(YearDropDown);
		DaySelect.selectByValue("2000");
	}

	public void checkBox() {
		SignCheckBox.click();
	}

	public void checkBox1() {
		ReceiveCheckBox.click();
	}

	public void VerifyFirstName() {
		FirstName.sendKeys("Gouse");
	}

	public void VerifyLastName() {
		LastName.sendKeys("Basha");
	}

	public void VerifyCompany() {
		Company.sendKeys("TCS");
	}

	public void VerifyAddress1() {
		Address1.sendKeys("Guntur");
	}

	public void VerifyAddress2() {
		Address2.sendKeys("Old Guntur");
	}

	public void VerifyState() {
		State.sendKeys("Andhra Pradesh");
	}

	public void VerifyCity2() {
		City.sendKeys("Guntur");
	}

	public void VerifyZipCode() {
		ZipCode.sendKeys("522001");
	}

	public void VerifyNumber() {
		Number.sendKeys("9398316764");
	}

	public void VerifyCreated() {
		AccCreated.click();
	}

	public String CreatedSuccessful() {
		String AccounntDispaly = Created.getText();
		return AccounntDispaly;

	}
	
	public void VerifyContinue() {
		Continue.click();
	}

}
