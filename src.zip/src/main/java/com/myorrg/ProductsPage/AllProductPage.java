package com.myorrg.ProductsPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AllProductPage {
	WebDriver driver;

	@FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[2]")
	WebElement clickProductElement;

	@FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div/h2")
	WebElement allProductElement;

	@FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div/div[2]/div/div[2]/ul/li/a")
	WebElement viewProductElement;
	
	@FindBy(xpath = "/html/body/section/div/div/div[2]/div[3]/div[1]/ul/li/a")
	WebElement writeReviewElement;
	
//	/html/body/section/div/div/div[2]/div[3]/div[1]/ul/li/a
	@FindBy(xpath = "//*[@id=\"name\"]")
	WebElement reviewNameElement;
	
	@FindBy(xpath = "//*[@id=\"email\"]")
	WebElement reviewEmailElement;
	
	@FindBy(xpath = "//*[@id=\"review\"]")
	WebElement addReviewElement;
	
	@FindBy(xpath = "//*[@id=\"button-review\"]")
	WebElement reviewSubmitElement;
	
	
	public AllProductPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void clickproduct() {
		clickProductElement.click();
	}

	public String productPage() {
		String productText = allProductElement.getText();
		return productText;
	}

	public void ViewProduct() {
		viewProductElement.click();
	}
	
	public String getReviewText() {
		String reviewText = writeReviewElement.getText();
		return reviewText;
	}
	public void reviewDetails(String reviewName, String reviewEmail, String reviewAddReview) {
		reviewNameElement.sendKeys(reviewName);
		reviewEmailElement.sendKeys(reviewEmail);
		addReviewElement.sendKeys(reviewAddReview);
		reviewSubmitElement.click();
		
		}
}
