package com.myorrg.ProductsPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ViewProductPage {
	WebDriver driver;

	@FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/h2")
	WebElement nameElement;

	@FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[1]")
	WebElement categoryElement;

	@FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/span")
	WebElement priceElement;

	@FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[2]")
	WebElement availabilityElement;

	@FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[3]")
	WebElement conditionElement;

	@FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[4]")
	WebElement brandElement;

	public ViewProductPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public String nameDetails() {
		String details = nameElement.getText();
		return details;
	}

	public String categoryDetails() {
		String details = categoryElement.getText();
		return details;
	}

	public String priceDetails() {
		String details = priceElement.getText();
		return details;
	}

	public String availabilityDetails() {
		String details = availabilityElement.getText();
		return details;
	}

	public String conditionDetails() {
		String details = conditionElement.getText();
		return details;
	}

	public String brandDetails() {
		String details = brandElement.getText();
		return details;
	}
}
