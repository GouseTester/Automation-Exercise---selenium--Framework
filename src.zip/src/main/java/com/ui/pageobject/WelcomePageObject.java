package com.ui.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class WelcomePageObject {

	WebDriver driver;
	By text = By.xpath("//*[@id=\"signInForm\"]/h1");
	By username = By.xpath("//*[@id=\"email\"]");
	By password = By.xpath("//*[@id=\"password\"]");
	By btn = By.xpath("//*[@id=\"signInForm\"]/div[3]/a");

	public WelcomePageObject(WebDriver driver) {
		this.driver = driver;

	}

	public String verifyHeading() {
		String pageHeading = driver.findElement(text).getText();
		return pageHeading;
	}

	public String verifyUserName() {
		String userName = driver.findElement(username).getText();
		return userName;
	}

	public String verifyPassword() {
		String userPassword = driver.findElement(password).getText();
		return userPassword;
	}

	public void ClickNewUser() {
		driver.findElement(btn).click();

	}

}
